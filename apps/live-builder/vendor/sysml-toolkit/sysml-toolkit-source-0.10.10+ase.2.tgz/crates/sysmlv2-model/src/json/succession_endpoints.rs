//! Lexical succession endpoints, projected into the shared implied graph.
use super::{Builder, membership_evidence, structural_index::StoredStructure};
use crate::metaclass::is_a;
use std::collections::{HashMap, hash_map::Entry};

type Neighbors = HashMap<(usize, usize), (Option<usize>, Option<usize>)>;

fn charge(steps: &mut usize, amount: usize) -> Option<()> {
    *steps = steps.saturating_add(amount);
    (*steps <= crate::eval::MAX_STEPS).then_some(())
}

/// The previous/next occurrence of each member, using the same lexical rule
/// for successions and target transitions. Parameters and connectors do not
/// advance the sequence; a message (a Flow without ends) does. Conditional
/// transitions likewise leave the previous occurrence in place for the next branch.
fn neighbors(
    b: &Builder,
    raw: &StoredStructure,
    owner: usize,
    steps: &mut usize,
) -> Option<Neighbors> {
    let mut members = Vec::new();
    charge(steps, b.elements[owner].owned_relationships.len())?;
    for &rel in &b.elements[owner].owned_relationships {
        let relation = b.elements.get(rel)?;
        // Non-owning memberships (including `first start`) are references,
        // not declarations in this sequence. An unresolved reference here
        // cannot invalidate otherwise complete lexical occurrence evidence.
        if !is_a!(relation, "OwningMembership") {
            continue;
        }
        let member = membership_evidence::member(b, raw, owner, rel, steps)?;
        let row = &b.elements[member];
        let parameter = is_a!(relation, "ParameterMembership")
            || ((is_a!(b.elements[owner], "Behavior") || is_a!(b.elements[owner], "Step"))
                && row.props.get("direction").is_some_and(|v| !v.is_null()));
        let message = if is_a!(row, "FlowUsage") {
            charge(steps, row.owned_relationships.len())?;
            let mut no_ends = true;
            for &r in &row.owned_relationships {
                let relationship = b.elements.get(r)?;
                if is_a!(relationship, "FeatureMembership") {
                    let feature = membership_evidence::member(b, raw, member, r, steps)?;
                    no_ends &= b.elements[feature]
                        .props
                        .get("isEnd")
                        .and_then(|v| v.as_bool())
                        != Some(true);
                }
            }
            no_ends
        } else {
            false
        };
        let occurrence = is_a!(relation, "FeatureMembership")
            && !parameter
            && is_a!(row, "OccurrenceUsage")
            && !is_a!(row, "TransitionUsage")
            && (!is_a!(row, "Connector") || message);
        members.push((rel, member, occurrence));
    }
    charge(steps, members.len().saturating_mul(2))?;
    let mut neighbors = HashMap::new();
    let mut previous = None;
    for &(rel, member, occurrence) in &members {
        neighbors.insert((rel, member), (previous, None));
        if occurrence {
            previous = Some(member);
        }
    }
    let mut next = None;
    for &(rel, member, occurrence) in members.iter().rev() {
        neighbors.get_mut(&(rel, member)).expect("checked member").1 = next;
        if occurrence {
            next = Some(member);
        }
    }
    Some(neighbors)
}

/// A transition's authored source feature, including a feature chain. `None`
/// inside `Some` proves that no source was authored; incomplete or invalid
/// explicit source evidence is never permission to infer a replacement.
fn explicit_source(
    b: &Builder,
    raw: &StoredStructure,
    transition: usize,
    steps: &mut usize,
) -> Option<Option<usize>> {
    charge(steps, b.elements[transition].owned_relationships.len())?;
    for &rel in &b.elements[transition].owned_relationships {
        let relation = b.elements.get(rel)?;
        if !is_a!(relation, "Membership") || is_a!(relation, "FeatureMembership") {
            continue;
        }
        let member = membership_evidence::member(b, raw, transition, rel, steps)?;
        if is_a!(relation, "OwningMembership") && is_a!(b.elements[member], "Succession") {
            continue;
        }
        if is_a!(b.elements[member], "Feature") {
            // Explicit feature chains remain authoritative. Their internal
            // succession projection is not this lexical shorthand rule.
            if super::type_relations::checked_feature_target(
                b,
                raw,
                member,
                &b.elements[member].owned_relationships,
                b.explicit_len(),
                steps,
            )?
            .is_some()
            {
                return None;
            }
            return (member != transition && is_a!(b.elements[member], "ActionUsage"))
                .then_some(Some(member));
        }
        // A plain Membership spells a source even if its member has the
        // wrong metaclass. OwningMemberships may instead own the succession.
        if !is_a!(relation, "OwningMembership") {
            return None;
        }
    }
    Some(None)
}

/// Implicit TransitionUsage source Membership recipes. Kept out of the
/// authored graph, so compact interchange, source text and digests retain the
/// user's shorthand. The shared publisher owns their identities and carriers.
/// A prepared library has already published its own rows; only the appended
/// source slice is scanned when extending that library.
pub(super) fn transition_sources_from(
    b: &mut Builder,
    start: usize,
    steps: &mut usize,
) -> Option<Vec<(usize, usize)>> {
    let limit = b.explicit_len();
    charge(steps, limit.saturating_sub(start))?;
    let transitions: Vec<_> = (start..limit)
        .filter(|&i| b.is_authored(i) && b.elements[i].ty == "TransitionUsage")
        .collect();
    transition_sources(b, transitions, steps)
}

/// Infer sources for an already charged authored TransitionUsage slice. Static
/// planning and succession planning gather this during their existing row scan,
/// so models without transitions pay no additional whole-model scan.
pub(super) fn transition_sources(
    b: &mut Builder,
    transitions: Vec<usize>,
    steps: &mut usize,
) -> Option<Vec<(usize, usize)>> {
    if transitions.is_empty() {
        return Some(Vec::new());
    }
    let raw = StoredStructure::for_query(b, steps)?;
    let domains = raw.membership_domains(b, steps)?;
    let mut bodies = HashMap::new();
    let mut out = Vec::new();
    for transition in transitions {
        charge(steps, 1)?;
        if !domains.owner_complete(transition)
            || explicit_source(b, &raw, transition, steps) != Some(None)
        {
            continue;
        }
        let Some(membership) = b.elements[transition].owning_relationship else {
            continue;
        };
        let Some(Some(owner)) = raw.carrier(b, membership) else {
            continue;
        };
        if !domains.owner_complete(owner) {
            continue;
        }
        if let Entry::Vacant(entry) = bodies.entry(owner) {
            entry.insert(neighbors(b, &raw, owner, steps).unwrap_or_default());
            charge(steps, 0)?;
        }
        if let Some(&(Some(source), _)) = bodies[&owner].get(&(membership, transition)) {
            if source != transition && is_a!(b.elements[source], "ActionUsage") {
                out.push((transition, source));
            }
        }
    }
    charge(steps, 0)?;
    Some(out)
}

/// Missing shorthand ends are resolved from the ordered owning Memberships.
/// No source rows are changed, and the static publisher owns the new identities.
pub(super) fn endpoints(b: &mut Builder, steps: &mut usize) -> Option<Vec<(usize, usize)>> {
    endpoints_from(b, 0, steps)
}

/// [`endpoints`] of the successions from row `start` on: a build extending a
/// prepared library's plans reads the library's own successions' endpoints
/// from them.
pub(super) fn endpoints_from(
    b: &mut Builder,
    start: usize,
    steps: &mut usize,
) -> Option<Vec<(usize, usize)>> {
    let limit = b.explicit_len();
    // Gather the small succession slice once. Scanning the whole graph again
    // after proving existence wastes the cold query's shared work allowance.
    charge(steps, limit.saturating_sub(start))?;
    let mut successions = Vec::new();
    let mut transitions = Vec::new();
    for i in (start..limit).filter(|&i| b.is_authored(i)) {
        if b.elements[i].ty == "SuccessionAsUsage" {
            charge(steps, 1)?;
            successions.push(i);
        } else if b.elements[i].ty == "TransitionUsage" {
            charge(steps, 1)?;
            transitions.push(i);
        }
    }
    if successions.is_empty() {
        return Some(Vec::new());
    }
    let raw = StoredStructure::for_query(b, steps)?;
    let domains = raw.membership_domains(b, steps)?;
    let inverse = raw.typing(b, steps)?;
    if inverse.sources_incomplete {
        return Some(Vec::new());
    }
    let transition_sources: HashMap<_, _> = transition_sources(b, transitions, steps)?
        .into_iter()
        .collect();
    let mut bodies: HashMap<usize, Neighbors> = HashMap::new();
    let mut out = Vec::new();
    for succession in successions {
        charge(steps, 1)?;
        let Some(membership) = b.elements[succession].owning_relationship else {
            continue;
        };
        let Some(Some(owner)) = raw.carrier(b, membership) else {
            continue;
        };
        if !domains.owner_complete(owner)
            || membership_evidence::member(b, &raw, owner, membership, steps) != Some(succession)
        {
            continue;
        }
        let transition = b.elements[owner].ty == "TransitionUsage";
        if let Entry::Vacant(entry) = bodies.entry(owner) {
            entry.insert(neighbors(b, &raw, owner, steps).unwrap_or_default());
            charge(steps, 0)?;
        }
        let Some(&(previous, next)) = bodies[&owner].get(&(membership, succession)) else {
            continue;
        };
        let source = if transition {
            match explicit_source(b, &raw, owner, steps) {
                Some(Some(source)) => Some(source),
                Some(None) => transition_sources
                    .get(&owner)
                    .copied()
                    .filter(|&source| is_a!(b.elements[source], "ActionUsage")),
                None => None,
            }
        } else {
            previous
        };
        let target = b.elements[succession]
            .path
            .ends_with("emptySuccession")
            .then_some(next)
            .flatten();
        let mut ends = Vec::new();
        let mut complete = domains.owner_complete(succession);
        charge(steps, b.elements[succession].owned_relationships.len())?;
        for &rel in &b.elements[succession].owned_relationships {
            let Some(relation) = b.elements.get(rel) else {
                complete = false;
                break;
            };
            if relation.ty != "EndFeatureMembership" {
                continue;
            }
            if let Some(end) = membership_evidence::member(b, &raw, succession, rel, steps) {
                ends.push(end);
            } else {
                complete = false;
                break;
            }
        }
        charge(steps, 0)?;
        if !complete || ends.len() != 2 {
            continue;
        }
        for (end, target) in ends.into_iter().zip([source, target]) {
            let Some(target) = target else { continue };
            charge(steps, b.elements[end].owned_relationships.len())?;
            let incoming = inverse
                .relationships
                .get(&end)
                .map(Vec::as_slice)
                .unwrap_or_default();
            charge(steps, incoming.len())?;
            if incoming.iter().any(|&r| r < limit) {
                continue;
            }
            // An unknown row or authored specialization prevents inventing
            // a replacement endpoint, including an existing reference subset.
            if b.elements[end]
                .owned_relationships
                .iter()
                .any(|&r| b.elements.get(r).is_none_or(|r| is_a!(r, "Specialization")))
            {
                continue;
            }
            if is_a!(b.elements[end], "Feature") && end != target {
                out.push((end, target));
            }
        }
    }
    Some(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{json::ResolvedModel, model::Model};
    fn build(count: usize) -> ResolvedModel {
        let mut source = String::from("action owner {");
        for n in 0..count {
            source.push_str(&format!("action a{n}; then a{n};"));
        }
        source.push('}');
        let mut model = Model::new();
        assert!(
            model
                .add_source("successions.sysml", &source)
                .diagnostics
                .is_empty()
        );
        ResolvedModel::build(&model)
    }
    #[test]
    fn lexical_projection_scales_linearly_and_budget_failure_is_retryable() {
        let mut r = build(2000);
        let mut steps = 0;
        let edges = endpoints(&mut r.b, &mut steps).unwrap();
        assert_eq!(edges.len(), 2000);
        assert!(steps < 2_000_000, "{steps}");
        let mut exhausted = crate::eval::MAX_STEPS;
        assert!(endpoints(&mut r.b, &mut exhausted).is_none());
        assert_eq!(endpoints(&mut r.b, &mut 0).unwrap(), edges);
    }
    #[test]
    fn standalone_specialization_of_empty_source_prevents_inference() {
        let mut r = build(1);
        let edges = endpoints(&mut r.b, &mut 0).unwrap();
        let (end, target) = edges[0];
        let owner = r.b.new_element("Namespace", None, "extra".into());
        let relation = r.b.new_relationship("ReferenceSubsetting", owner, "source");
        r.b.set(
            relation,
            "subsettingFeature",
            serde_json::json!({"@id": r.b.elements[end].id.to_string()}),
        );
        r.b.set(
            relation,
            "referencedFeature",
            serde_json::json!({"@id": r.b.elements[target].id.to_string()}),
        );
        assert!(endpoints(&mut r.b, &mut 0).unwrap().is_empty());
    }
}

#[cfg(test)]
mod transition_tests {
    use super::*;
    use crate::{
        json::{Derived, DerivedValue, ElementRef, Reference, ResolvedModel},
        model::Model,
    };
    use serde_json::json;

    fn fixture(source: &str) -> (Model, ResolvedModel) {
        let mut model = Model::new();
        let parsed = model.add_source("transitions.sysml", source);
        assert!(parsed.diagnostics.is_empty(), "{:?}", parsed.diagnostics);
        let resolved = ResolvedModel::build(&model);
        (model, resolved)
    }
    fn transitions(r: &ResolvedModel) -> Vec<ElementRef> {
        r.user_elements()
            .filter(|&e| r.element_type(e) == "TransitionUsage")
            .collect()
    }
    fn source(r: &mut ResolvedModel, transition: ElementRef) -> Option<ElementRef> {
        match r.derived(transition, "source") {
            Derived::Value(value) => value.element(),
            other => panic!("{other:?}"),
        }
    }
    fn assert_source(r: &mut ResolvedModel, transition: ElementRef, name: &str) {
        let expected = r.resolve_qualified(name).unwrap();
        assert_eq!(source(r, transition), Some(expected));
        assert_eq!(r.transition_parts(transition).source, Some(expected));
        assert_eq!(
            r.property(transition, "source").unwrap(),
            json!({"@id": r.element_id(expected).to_string()})
        );
        let succession = r.d_succession(transition).unwrap();
        assert_eq!(
            r.derived(succession, "sourceFeature"),
            Derived::Value(DerivedValue::Reference(Reference::Element(expected)))
        );
        let related = r.derived(succession, "relatedFeature");
        assert!(
            matches!(related, Derived::Value(DerivedValue::References(ref ends)) if ends.len() == 2 && ends[0].element() == Some(expected)),
            "{related:?}"
        );
        assert_ne!(expected, transition);
    }

    #[test]
    fn implicit_transition_sources_are_shared_by_all_semantic_reads_and_full_json() {
        let (model, mut r) =
            fixture("action a { action b; action c; decide d; if true then b; else c; }");
        let compact = r.built_compact_json_with_units().unwrap();
        let ts = transitions(&r);
        assert_eq!(ts.len(), 2);
        for &t in &ts {
            assert_source(&mut r, t, "a::d");
        }
        let full = crate::full::resolved_to_full_json(&mut r, &model, Default::default()).unwrap();
        let rows = full.as_array().unwrap();
        let source = r.resolve_qualified("a::d").unwrap();
        let source_id = r.element_id(source).to_string();
        for t in ts {
            let id = r.element_id(t).to_string();
            let row = rows.iter().find(|row| row["@id"] == id).unwrap();
            assert_eq!(row["source"], json!({"@id": source_id}));
            let memberships: Vec<_> = r
                .implied_relationships(t)
                .into_iter()
                .filter(|&m| r.element_type(m) == "Membership")
                .collect();
            assert_eq!(memberships.len(), 1);
            let membership_id = r.element_id(memberships[0]).to_string();
            assert!(
                row["ownedRelationship"]
                    .as_array()
                    .unwrap()
                    .contains(&json!({"@id": membership_id}))
            );
            let membership = rows.iter().find(|row| row["@id"] == membership_id).unwrap();
            assert_eq!(membership["memberElement"], json!({"@id": source_id}));
            assert_eq!(membership["isImplied"], true);
        }
        assert_eq!(r.built_compact_json_with_units().unwrap(), compact);
        assert_eq!(crate::json::model_to_compact_json(&model), compact.0);
    }

    #[test]
    fn unnamed_decision_branches_share_the_same_source() {
        let (_, mut r) = fixture(
            "action a { action b; action c; decide; if true then b; if false then c; else b; }",
        );
        let decision = r
            .user_elements()
            .find(|&e| r.element_type(e) == "DecisionNode")
            .unwrap();
        for t in transitions(&r) {
            assert_eq!(source(&mut r, t), Some(decision));
            assert_eq!(r.transition_parts(t).source, Some(decision));
        }
    }

    #[test]
    fn conditional_branches_and_interleaved_then_do_not_become_previous_occurrences() {
        let (_, mut r) = fixture(
            "action a { action b; action c; decide d; if true then b; then c; else c; then action next; if true then b; }",
        );
        let ts = transitions(&r);
        assert_eq!(ts.len(), 3);
        assert_source(&mut r, ts[0], "a::d");
        assert_source(&mut r, ts[1], "a::d");
        assert_source(&mut r, ts[2], "a::next");
    }

    #[test]
    fn parameters_non_occurrences_and_connectors_do_not_replace_the_source() {
        let (_, mut r) = fixture(
            "action a { action b; action c; decide d; in item p; attribute count; binding bind p = p; if true then b; else c; }",
        );
        for t in transitions(&r) {
            assert_source(&mut r, t, "a::d");
        }
    }

    #[test]
    fn unresolved_initial_marker_does_not_hide_the_preceding_occurrence() {
        let (_, mut r) = fixture(
            "action a { action target; decide d; first start; then target; if true then target; else target; }",
        );
        for t in transitions(&r) {
            assert_source(&mut r, t, "a::d");
        }
    }

    #[test]
    fn transition_source_membership_does_not_enter_dynamic_specialization_graph() {
        let (_, mut r) = fixture(
            "calc def F { in x; return result; } action a { action target; decide d; if F(1) then target; }",
        );
        let t = transitions(&r)[0];
        assert_source(&mut r, t, "a::d");
        let d = r.resolve_qualified("a::d").unwrap();
        let f = r.resolve_qualified("F").unwrap();
        let invocation = r
            .user_elements()
            .find(|&e| r.element_type(e) == "InvocationExpression")
            .unwrap();
        assert!(r.b.effective_dynamic_plan().is_some());
        assert!(r.conforms_with_implied(invocation, f));
        assert!(!r.conforms_with_implied(t, d));
        let plan = r.b.effective_dynamic_plan().unwrap();
        let t_id = r.element_id(t);
        let d_id = r.element_id(d);
        assert!(
            plan.static_prefix
                .rows
                .iter()
                .any(|row| row.kind == "Membership" && row.owner == t.0 && row.target == d_id)
        );
        assert!(
            !plan
                .specializations
                .get(&t_id)
                .is_some_and(|targets| targets.contains(&d_id))
        );
    }

    #[test]
    fn state_and_triggered_shorthands_use_the_previous_state() {
        let (_, mut r) = fixture(
            "item def Event; state def S { state target; state waiting; accept Event then target; if true then target; else target; }",
        );
        for t in transitions(&r) {
            assert_source(&mut r, t, "S::waiting");
        }
    }

    #[test]
    fn absent_or_nested_sources_never_escape_the_owning_body() {
        let (_, mut r) = fixture(
            "action outer { action target; action preceding; action inner { if true then target; else target; } }",
        );
        for t in transitions(&r) {
            assert_eq!(source(&mut r, t), None);
            assert_eq!(r.transition_parts(t).source, None);
            let succession = r.d_succession(t).unwrap();
            assert!(
                r.implied_relationships(succession)
                    .into_iter()
                    .all(|e| r.element_type(e) != "Membership")
            );
        }
    }

    #[test]
    fn explicit_source_is_authoritative_even_when_unresolved_or_wrong_kind() {
        let (_, mut r) = fixture(
            "action a { action b; action c; attribute invalid; decide d; transition first b if true then c; transition first absent if true then c; transition first invalid if true then c; }",
        );
        let ts = transitions(&r);
        assert_source(&mut r, ts[0], "a::b");
        assert_eq!(source(&mut r, ts[1]), None);
        assert_eq!(source(&mut r, ts[2]), None);
        for &t in &ts {
            assert!(
                r.implied_relationships(t)
                    .into_iter()
                    .all(|e| r.element_type(e) != "Membership")
            );
        }
        for &t in &ts[1..] {
            let succession = r.d_succession(t).unwrap();
            let source_end = r.d_ends(r.d_owned_features(succession))[0];
            assert!(r.implied_relationships(source_end).is_empty());
        }
    }

    #[test]
    fn invalid_explicit_self_source_is_rejected_without_lexical_fallback() {
        let (_, mut r) = fixture(
            "action a { action target; decide d; transition t first t if true then target; }",
        );
        let t = transitions(&r)[0];
        assert_eq!(source(&mut r, t), None);
        assert_eq!(r.transition_parts(t).source, None);
        assert!(r.property(t, "source").is_err());
        assert!(
            r.implied_relationships(t)
                .into_iter()
                .all(|e| r.element_type(e) != "Membership")
        );
        let succession = r.d_succession(t).unwrap();
        let source_end = r.d_ends(r.d_owned_features(succession))[0];
        assert!(r.implied_relationships(source_end).is_empty());
    }

    #[test]
    fn explicit_chained_source_remains_authored_without_lexical_replacement() {
        let (_, mut r) = fixture(
            "action a { action nested { action start; } action target; decide d; transition first nested.start if true then target; transition first nested.absent if true then target; }",
        );
        let ts = transitions(&r);
        let expected = r.resolve_qualified("a::nested::start").unwrap();
        assert_eq!(source(&mut r, ts[0]), Some(expected));
        assert_eq!(source(&mut r, ts[1]), None);
        // Preserve the public parts API's authored chain identity, including
        // an unresolved chain, rather than replacing it with lexical d.
        for t in ts {
            let chain = r.transition_parts(t).source.unwrap();
            assert_eq!(r.element_type(chain), "Feature");
            assert!(
                r.implied_relationships(t)
                    .into_iter()
                    .all(|e| r.element_type(e) != "Membership")
            );
            let succession = r.d_succession(t).unwrap();
            let source_end = r.d_ends(r.d_owned_features(succession))[0];
            assert!(r.implied_relationships(source_end).is_empty());
        }
    }

    #[test]
    fn reject_branch_keeps_its_distinct_target_and_never_creates_a_self_edge() {
        let (_, mut r) = fixture(
            "action a { action approve; action reject; decide choice; if true then approve; else reject; }",
        );
        let ts = transitions(&r);
        let reject = r.resolve_qualified("a::reject").unwrap();
        assert_source(&mut r, ts[1], "a::choice");
        let parts = r.transition_parts(ts[1]);
        assert_eq!(parts.target, Some(reject));
        assert_ne!(parts.source, parts.target);
        for (end, target) in endpoints(&mut r.b, &mut 0).unwrap() {
            assert_ne!(end, target);
            assert_ne!(r.element_type(ElementRef(target)), "TransitionUsage");
        }
    }

    #[test]
    fn message_is_a_sequence_occurrence_while_an_ordinary_connector_is_not() {
        let (_, mut r) = fixture(
            "action a { item p; item q; action firstAction; connection connect p to q; then firstAction; message signal; then firstAction; }",
        );
        let action = r.resolve_qualified("a::firstAction").unwrap().0;
        let message = r.resolve_qualified("a::signal").unwrap().0;
        let edges = endpoints(&mut r.b, &mut 0).unwrap();
        assert_eq!(
            edges.iter().map(|&(_, target)| target).collect::<Vec<_>>(),
            vec![action, message]
        );
    }

    #[test]
    fn directed_occurrences_are_parameters_even_without_parameter_memberships() {
        let (_, mut r) =
            fixture("action a { action target; decide d; action directed; if true then target; }");
        let directed = r.resolve_qualified("a::directed").unwrap();
        r.b.set(directed.0, "direction", json!("in"));
        let t = transitions(&r)[0];
        assert_source(&mut r, t, "a::d");
    }

    #[test]
    fn changed_lexical_evidence_does_not_reuse_a_stale_implicit_source() {
        let (_, mut r) = fixture("action a { action target; decide d; if true then target; }");
        let t = transitions(&r)[0];
        assert_source(&mut r, t, "a::d");
        let decision = r.resolve_qualified("a::d").unwrap();
        r.b.set(decision.0, "direction", json!("in"));
        assert_eq!(source(&mut r, t), None);
        assert_eq!(r.transition_parts(t).source, None);
    }

    #[test]
    fn prepared_library_snapshot_keeps_library_sources_and_plans_appended_sources() {
        let mut library = Model::new();
        library.add_library_source("library.sysml", "package Lib { action a { action target; decide d; if true then target; else target; } }");
        let prepared = library.prepare_library().unwrap();
        prepared.make_plans();
        let bytes = prepared.to_bytes(13).unwrap();
        let decoded =
            std::sync::Arc::new(crate::prepared::PreparedLibrary::from_bytes(&bytes, 13).unwrap());
        let mut model = Model::new();
        decoded.install(&mut model).unwrap();
        model.add_source(
            "user.sysml",
            "action user { action target; decide d; if true then target; else target; }",
        );
        let mut r = ResolvedModel::build(&model);
        let library_action = r.resolve_qualified("Lib::a").unwrap();
        let library_transitions: Vec<_> = r
            .d_owned_features(library_action)
            .into_iter()
            .filter(|&e| r.element_type(e) == "TransitionUsage")
            .collect();
        assert_eq!(library_transitions.len(), 2);
        for t in library_transitions {
            assert_source(&mut r, t, "Lib::a::d");
        }
        for t in transitions(&r) {
            assert_source(&mut r, t, "user::d");
        }
        let prefix =
            r.b.static_specialization_prefix(&r.b.implied_names(), true, Some(&mut 0))
                .unwrap();
        assert!(
            prefix
                .rows
                .iter()
                .filter(|row| row.kind == "Membership")
                .all(|row| row.owner >= r.b.lib_boundary)
        );
    }

    #[test]
    fn transition_source_planning_is_linear_and_budget_failure_is_retryable() {
        let mut text = String::from("action a { action target; decide d;");
        for _ in 0..1000 {
            text.push_str("if true then target;");
        }
        text.push('}');
        let (_, mut r) = fixture(&text);
        let mut steps = 0;
        let sources = transition_sources_from(&mut r.b, 0, &mut steps).unwrap();
        assert_eq!(sources.len(), 1000);
        assert!(steps < 2_000_000, "{steps}");
        let mut exhausted = crate::eval::MAX_STEPS;
        assert!(transition_sources_from(&mut r.b, 0, &mut exhausted).is_none());
        assert_eq!(
            transition_sources_from(&mut r.b, 0, &mut 0).unwrap(),
            sources
        );
    }
}
