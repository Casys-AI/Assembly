//! Native tests over the wasm binding surface. The binding's boundary
//! is JSON strings and plain handles — no JS types — so everything here
//! runs on the host; the wasm target changes the ABI, not the logic
//! (the wasm32 build is gated by `cargo check --target
//! wasm32-unknown-unknown -p sysmlv2-wasm`).

use sysmlv2_wasm::{
    Session, canonical_name_js, canonicalize_compact, check, graph_normalize_compact,
    spell_reference_js, state_digest_of, version,
};

fn sources(pairs: &[(&str, &str)]) -> String {
    serde_json::to_string(
        &pairs
            .iter()
            .map(|(n, t)| serde_json::json!({"name": n, "text": t}))
            .collect::<Vec<_>>(),
    )
    .unwrap()
}

/// A byte offset reported as a JSON number, as an index.
fn offset(v: &serde_json::Value) -> usize {
    usize::try_from(v.as_u64().expect("offset is a number")).expect("offset indexes this host")
}

const FLASHLIGHT: &str = "package Flashlight {\n    part def Body;\n    part def Battery {\n        attribute voltage = 3;\n    }\n    part flashlight {\n        part body : Body;\n        part battery : Battery;\n    }\n}\n";

#[test]
fn checked_properties_and_strict_export() {
    let mut s =
        Session::from_sources(&sources(&[("m.sysml", "package P { interface def I; }")])).unwrap();
    let i = s.resolve("P::I").unwrap();
    assert_eq!(s.property(&i, "isSufficient").unwrap(), "true");
    assert!(s.to_full_json_strict().is_err());
    let mut s = Session::from_sources(&sources(&[("m.sysml", "package P;")])).unwrap();
    assert!(
        s.to_full_json_strict()
            .unwrap()
            .contains("\"isImpliedIncluded\":false")
    );
}

#[test]
fn session_navigation_and_query() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let pkg = s.resolve("Flashlight").expect("package resolves");
    assert_eq!(s.metaclass(&pkg).unwrap(), "Package");
    assert_eq!(
        s.qualified_name(&pkg).unwrap().as_deref(),
        Some("Flashlight")
    );
    let members = s.members(&pkg).unwrap();
    assert_eq!(members.len(), 3);
    let battery = s.resolve("Flashlight::flashlight::battery").unwrap();
    let typings = s.typings(&battery).unwrap();
    assert_eq!(typings.len(), 1);
    assert_eq!(
        s.qualified_name(&typings[0]).unwrap().as_deref(),
        Some("Flashlight::Battery")
    );
    let owner = s.owner(&battery).unwrap().expect("owned");
    assert_eq!(
        s.qualified_name(&owner).unwrap().as_deref(),
        Some("Flashlight::flashlight")
    );
    assert!(!s.is_library_element(&battery).unwrap());
    assert_eq!(s.elements_of_metaclass("PartDefinition").len(), 2);

    let voltage = s.resolve("Flashlight::Battery::voltage").unwrap();
    assert_eq!(s.evaluate(&voltage).unwrap(), "3");
    let q: serde_json::Value =
        serde_json::from_str(&s.query("Flashlight::Battery::voltage + 1").unwrap()).unwrap();
    assert_eq!(q, serde_json::json!(4));
}

#[test]
fn roots_walk_the_outline() {
    let mut s = Session::from_sources(&sources(&[
        ("flashlight.sysml", FLASHLIGHT),
        ("extra.sysml", "package Extra { part def Case; }"),
    ]))
    .unwrap();
    let roots = s.roots();
    let names: Vec<Option<String>> = roots.iter().map(|e| s.name(e).unwrap()).collect();
    assert_eq!(
        names,
        vec![Some("Flashlight".to_string()), Some("Extra".to_string())]
    );
    // Outline recursion: members of a root are reachable and named.
    let members = s.members(&roots[0]).unwrap();
    assert_eq!(members.len(), 3);
    assert_eq!(s.metaclass(&members[0]).unwrap(), "PartDefinition");
}

#[test]
fn units_and_interchange_roundtrip() {
    let s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let units: serde_json::Value = serde_json::from_str(&s.units()).unwrap();
    assert_eq!(units.as_array().unwrap().len(), 1);
    assert_eq!(units[0]["name"], "flashlight.sysml");
    assert!(
        units[0]["text"]
            .as_str()
            .unwrap()
            .contains("part def Battery")
    );

    let full = s.to_full_json(true);
    let mut back = Session::from_interchange_json(&full, None, None, None).unwrap();
    assert!(back.resolve("Flashlight::flashlight::battery").is_some());
    assert_eq!(back.unresolved_count(), 0);
    let warnings: serde_json::Value = serde_json::from_str(&back.warnings()).unwrap();
    assert_eq!(warnings, serde_json::json!([]));

    let compact = s.to_compact_json();
    assert!(compact.contains("\"@type\""));
}

/// The units `describeCbor` reports for the session's compact CBOR
/// payload, as `[[index, path], …]`; `[]` for a payload that carries none.
fn described_units(s: &Session) -> serde_json::Value {
    let described: serde_json::Value =
        serde_json::from_str(&sysmlv2_wasm::describe_cbor(&s.to_compact_cbor()).unwrap()).unwrap();
    described
        .get("units")
        .and_then(serde_json::Value::as_array)
        .into_iter()
        .flatten()
        .map(|u| serde_json::json!([u["index"], u["path"]]))
        .collect()
}

#[test]
fn the_unit_table_is_the_units_the_compact_payload_carries() {
    let assert_table = |s: &Session, what: &str| {
        let table: serde_json::Value = serde_json::from_str(&s.unit_table()).unwrap();
        assert_eq!(table, described_units(s), "{what}");
        table
    };
    let one = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    assert_eq!(
        assert_table(&one, "one unit"),
        serde_json::json!([[0, "flashlight.sysml"]])
    );
    let units = [
        ("model/a.sysml", "package A { part def P; }"),
        ("model/empty.sysml", ""),
        (
            "model/b.sysml",
            "package B { part p : A::P; part q : A::P; }",
        ),
        ("c.sysml", "package C { attribute def K; }"),
    ];
    let several = Session::from_sources(&sources(&units)).unwrap();
    let table = assert_table(&several, "several units");
    let paths: Vec<&str> = table
        .as_array()
        .unwrap()
        .iter()
        .map(|entry| entry[1].as_str().unwrap())
        .collect();
    assert_eq!(paths, units.map(|(name, _)| name));
    let library = sources(&[(
        "lib.sysml",
        "standard library package Lib { part def Base; }",
    )]);
    let on_library = Session::from_sources_with_library(
        &sources(&[
            ("u.sysml", "package U { part def Car :> Lib::Base; }"),
            ("v.sysml", "package V { part car : U::Car; }"),
        ]),
        Some(library.clone()),
        None,
    )
    .unwrap();
    assert_table(&on_library, "on a library");
    let lifted =
        Session::from_interchange_json(&several.to_compact_json(), None, None, None).unwrap();
    assert_table(&lifted, "lifted from compact JSON");
    let decoded = Session::from_compact_cbor(&several.to_compact_cbor(), None, None, None).unwrap();
    assert_eq!(
        assert_table(&decoded, "decoded from compact CBOR"),
        table,
        "a payload's units survive its decode"
    );
    // A payload in the canonical graph format opens a session in it.
    let canonical = sysmlv2_transform::Session::from_sources_with_graph_format(
        units
            .iter()
            .map(|(name, text)| (name.to_string(), text.to_string()))
            .collect(),
        None,
        sysmlv2_model::model::GraphFormat::CanonicalV3,
    )
    .unwrap();
    let canonical =
        Session::from_compact_cbor(&canonical.to_compact_cbor(), None, None, None).unwrap();
    assert_eq!(
        sysmlv2_cbor::graph_format(&canonical.to_compact_cbor()).unwrap(),
        sysmlv2_model::model::GraphFormat::CanonicalV3
    );
    assert_table(&canonical, "the canonical graph format");
    // A document whose every id is respelled keeps its ids as explicit.
    let mut document = several.to_compact_json();
    let compact: serde_json::Value = serde_json::from_str(&document).unwrap();
    for (k, element) in compact.as_array().unwrap().iter().enumerate() {
        let id = element["@id"].as_str().unwrap();
        document = document.replace(id, &format!("{k:08x}{}", &id[8..]));
    }
    let explicit = Session::from_interchange_json(&document, None, None, None).unwrap();
    let described: serde_json::Value =
        serde_json::from_str(&sysmlv2_wasm::describe_cbor(&explicit.to_compact_cbor()).unwrap())
            .unwrap();
    assert_eq!(described["explicitIds"], true);
    assert_table(&explicit, "explicit ids");
}

#[test]
fn annotation_targets_are_navigable() {
    let src = "package P {
        part def A;
        metadata def M;
        metadata record : M about A;
        metadata dangling : M about Missing;
    }";
    let mut s = Session::from_sources(&sources(&[("annotations.sysml", src)])).unwrap();
    let record = s.resolve("P::record").unwrap();
    let targets = s.annotated_elements(&record).unwrap();
    assert_eq!(targets.len(), 1);
    assert_eq!(
        s.qualified_name(&targets[0]).unwrap().as_deref(),
        Some("P::A")
    );
    let dangling = s.resolve("P::dangling").unwrap();
    assert!(s.annotated_elements(&dangling).unwrap().is_empty());
}

#[test]
fn canonicalize_compact_bridges_default_elision() {
    let s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let compact = s.to_compact_json();
    let spelled = canonicalize_compact(&compact).unwrap();

    // Simulate the service's wire elision: drop the default-valued
    // spellings a session document carries explicitly.
    let mut doc: serde_json::Value = serde_json::from_str(&compact).unwrap();
    let mut dropped = 0usize;
    for el in doc.as_array_mut().unwrap() {
        let id = el["@id"].clone();
        let obj = el.as_object_mut().unwrap();
        for (k, d) in [
            ("isUnique", serde_json::json!(true)),
            ("isAbstract", serde_json::json!(false)),
            ("visibility", serde_json::json!("public")),
            ("elementId", id),
        ] {
            if obj.get(k) == Some(&d) && obj.remove(k).is_some() {
                dropped += 1;
            }
        }
    }
    assert!(dropped > 0, "the elision simulation bites");
    let from_wire = canonicalize_compact(&doc.to_string()).unwrap();
    assert_eq!(spelled, from_wire, "elision split is bridged");
    assert_eq!(
        canonicalize_compact(&spelled).unwrap(),
        spelled,
        "idempotent"
    );
    assert!(canonicalize_compact("[{\"@type\": \"Nope\", \"@id\": \"x\"}]").is_err());
}

#[test]
fn graph_normalize_compact_digests_a_javascript_print_as_the_kernel_document() {
    // `JSON.parse` + `JSON.stringify` print the kernel's `150.0` as
    // `150`: the session's document and that print graph-normalize to
    // one document, so a state digests alike from either; the
    // as-spelled normalization still tells them apart.
    let s = Session::from_sources(&sources(&[(
        "values.sysml",
        "package Values { attribute power = 150.0; attribute ratio = 2.5; attribute count = 3; }",
    )]))
    .unwrap();
    let compact = s.to_compact_json();
    assert!(
        compact.contains("150.0"),
        "the kernel spells the real as a float"
    );
    let printed = compact.replace("150.0", "150");
    let digest = |json: &str, as_spelled| {
        state_digest_of(&graph_normalize_compact(json, as_spelled).unwrap()).unwrap()
    };
    assert_eq!(
        graph_normalize_compact(&printed, None).unwrap(),
        graph_normalize_compact(&compact, None).unwrap()
    );
    assert_eq!(digest(&printed, None), digest(&compact, None));
    assert_eq!(
        digest(&compact, Some(true)),
        digest(&compact, None),
        "the kernel's own spelling normalizes as before"
    );
    assert_ne!(digest(&printed, Some(true)), digest(&compact, None));
}

#[test]
fn graph_normalize_compact_lands_in_the_stored_digest_cell() {
    // The mirror twin: a session document (kernel spelling) and its
    // canonicalized (maximally spelled) form graph-normalize to the
    // SAME document — the stored spelling a graph-backed service
    // reconstructs — so one state digest covers both spellings.
    let s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let compact = s.to_compact_json();
    let normal = graph_normalize_compact(&compact, None).unwrap();
    let spelled = canonicalize_compact(&compact).unwrap();
    assert_eq!(
        graph_normalize_compact(&spelled, None).unwrap(),
        normal,
        "spelling domains collapse"
    );
    assert_eq!(
        graph_normalize_compact(&normal, None).unwrap(),
        normal,
        "idempotent"
    );
    assert_eq!(
        state_digest_of(&graph_normalize_compact(&spelled, None).unwrap()).unwrap(),
        state_digest_of(&normal).unwrap(),
        "one digest cell"
    );
    // The stored spelling elides defaults the kernel spells, and pins
    // elements to id order.
    let doc: serde_json::Value = serde_json::from_str(&normal).unwrap();
    let arr = doc.as_array().unwrap();
    let ids: Vec<&str> = arr.iter().map(|e| e["@id"].as_str().unwrap()).collect();
    let mut sorted = ids.clone();
    sorted.sort_unstable();
    assert_eq!(ids, sorted, "id-sorted listing order");
    assert!(
        arr.iter().all(|e| e["elementId"].is_string()),
        "elementId always spelled"
    );
    assert!(
        arr.iter()
            .all(|e| e.as_object().unwrap().get("isUnique") != Some(&serde_json::json!(true))),
        "true-default isUnique elided"
    );
    assert!(graph_normalize_compact("[{\"@type\": \"Nope\", \"@id\": \"x\"}]", None).is_err());
}

#[test]
fn plantuml_views_and_options() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let uml = s.to_plantuml(None).unwrap();
    assert!(uml.starts_with("@startuml"));
    assert!(uml.contains("Battery"));
    let ic = s
        .to_plantuml(Some(
            r#"{"view": "ic", "element": "Flashlight::flashlight", "horizontal": true}"#.into(),
        ))
        .unwrap();
    assert!(ic.starts_with("@startuml"));
    assert!(s.to_plantuml(Some(r#"{"view": "nope"}"#.into())).is_err());
    assert!(
        s.to_plantuml(Some(r#"{"element": "No::Such"}"#.into()))
            .is_err()
    );
    assert!(s.to_plantuml(Some(r#"{"vieww": "tree"}"#.into())).is_err());
}

#[test]
fn stale_handles_error_after_library_load() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let pkg = s.resolve("Flashlight").unwrap();
    s.load_library_sources(
        &sources(&[(
            "MiniLib.kerml",
            "standard library package MiniLib { class Thing; }",
        )]),
        None,
    )
    .unwrap();
    assert!(s.qualified_name(&pkg).is_err());
    let thing = s
        .resolve("MiniLib::Thing")
        .expect("library element resolves");
    assert!(s.is_library_element(&thing).unwrap());
}

#[test]
fn check_findings_shape() {
    // Clean parse: no findings without a library.
    let clean = check(&sources(&[("flashlight.sysml", FLASHLIGHT)]), None, None).unwrap();
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(&clean).unwrap(),
        serde_json::json!([])
    );

    // A parse error is a finding with a 1-based position.
    let bad = check(&sources(&[("bad.sysml", "part def {")]), None, None).unwrap();
    let bad: serde_json::Value = serde_json::from_str(&bad).unwrap();
    let f = &bad.as_array().unwrap()[0];
    assert_eq!(f["severity"], "error");
    assert_eq!(f["unit"], "bad.sysml");
    assert!(f["line"].as_u64().unwrap() >= 1);

    // In-memory library: an unresolved reference is only diagnosed when
    // referential checks run, and the library satisfies it.
    let lib = sources(&[(
        "MiniLib.kerml",
        "standard library package MiniLib { class Thing; }",
    )]);
    let user = sources(&[(
        "uses.sysml",
        "package Uses { part def Widget; part w : Widget; }",
    )]);
    let with_lib = check(&user, Some(lib.clone()), None).unwrap();
    let with_lib: serde_json::Value = serde_json::from_str(&with_lib).unwrap();
    assert_eq!(with_lib, serde_json::json!([]));

    // Findings carry an end position spanning the whole diagnosed
    // construct, not just its start.
    let user = sources(&[("dangling.sysml", "package Dangling { part w : Missing; }")]);
    let dangling = check(&user, Some(lib), None).unwrap();
    let dangling: serde_json::Value = serde_json::from_str(&dangling).unwrap();
    let f = &dangling.as_array().unwrap()[0];
    assert_eq!(f["severity"], "warning");
    assert_eq!(f["endLine"], f["line"]);
    assert_eq!(
        f["endCol"].as_u64().unwrap(),
        f["col"].as_u64().unwrap() + "Missing".len() as u64
    );
}

/// A user root package named like a standard-library root: `check`
/// reports the collision at the user declaration, and `resolve` keeps
/// landing on the library package (the behavior the warning describes).
#[test]
fn check_reports_user_roots_shadowing_library_roots() {
    let lib = sources(&[(
        "MiniLib.sysml",
        "standard library package Requirements { requirement def Base; }",
    )]);
    let user = sources(&[(
        "shadow.sysml",
        "package Requirements {\n    requirement def Speed;\n}\n",
    )]);
    let findings = check(&user, Some(lib.clone()), None).unwrap();
    let findings: serde_json::Value = serde_json::from_str(&findings).unwrap();
    assert_eq!(
        findings,
        serde_json::json!([{
            "severity": "warning",
            "stage": "referential",
            "message": "root package `Requirements` shadows the standard library package \
                        `Requirements`; references resolve to the library",
            "unit": "shadow.sysml",
            "line": 1,
            "col": 9,
            "endLine": 1,
            "endCol": 9 + "Requirements".len(),
        }])
    );
    // Without a library there is nothing to shadow.
    let alone = check(&user, None, None).unwrap();
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(&alone).unwrap(),
        serde_json::json!([])
    );

    let mut s = Session::from_sources(&user).unwrap();
    s.load_library_sources(&lib, None).unwrap();
    let pkg = s.resolve("Requirements").expect("the root name resolves");
    assert_eq!(s.metaclass(&pkg).unwrap(), "LibraryPackage");
    assert!(s.is_library_element(&pkg).unwrap());
    assert!(s.resolve("Requirements::Speed").is_none());
}

#[test]
fn version_matches_crate() {
    assert_eq!(version(), env!("CARGO_PKG_VERSION"));
}

/// The LSP surface over the wasm boundary: a push conversation through
/// the exported class (string transport, no threads).
#[test]
fn lsp_server_push_conversation() {
    let mut lsp = sysmlv2_wasm::LspServer::new();
    let out = lsp
        .handle(r#"{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"capabilities":{}}}"#)
        .unwrap();
    assert!(out[0].contains("sysmlv2-lsp"));
    let out = lsp
        .handle(
            r#"{"jsonrpc":"2.0","method":"textDocument/didOpen","params":{"textDocument":{"uri":"file:///w/m.sysml","languageId":"sysml","version":1,"text":"package P { part def X; }"}}}"#,
        )
        .unwrap();
    assert!(out.iter().any(|m| m.contains("publishDiagnostics")));
    let out = lsp
        .handle(
            r#"{"jsonrpc":"2.0","id":2,"method":"textDocument/documentSymbol","params":{"textDocument":{"uri":"file:///w/m.sysml"}}}"#,
        )
        .unwrap();
    assert!(
        out[0].contains("\"P\""),
        "symbol tree names the package: {}",
        out[0]
    );

    // The library shape through the factory: completions offer library
    // names.
    let mut lib_lsp = sysmlv2_wasm::LspServer::with_library(
        &sources(&[(
            "MiniLib.kerml",
            "standard library package MiniLib { class Widget; }",
        )]),
        None,
    )
    .unwrap();
    lib_lsp
        .handle(r#"{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"capabilities":{}}}"#)
        .unwrap();
    lib_lsp
        .handle(
            r#"{"jsonrpc":"2.0","method":"textDocument/didOpen","params":{"textDocument":{"uri":"file:///w/m.sysml","languageId":"sysml","version":1,"text":"package P { }"}}}"#,
        )
        .unwrap();
    let out = lib_lsp
        .handle(
            r#"{"jsonrpc":"2.0","id":2,"method":"textDocument/completion","params":{"textDocument":{"uri":"file:///w/m.sysml"},"position":{"line":0,"character":10}}}"#,
        )
        .unwrap();
    assert!(
        out[0].contains("Widget"),
        "library member offered: {}",
        out[0]
    );
}

/// The snapshot path: a sealed snapshot recorded against library
/// sources replays through `loadLibrarySources`, and the warm build is
/// byte-identical to the cold one (the equivalence gate, over the
/// wasm surface). Foreign/stale snapshot bytes fall back to a cold
/// build instead of corrupting resolution.
#[test]
fn library_snapshot_replays_and_rejects_garbage() {
    let lib_units = vec![
        (
            "MiniLib.kerml".to_string(),
            "standard library package MiniLib { class Thing; class Widget specializes Thing; }"
                .to_string(),
        ),
        (
            "MiniLib2.kerml".to_string(),
            "standard library package MiniLib2 { class Gadget specializes MiniLib::Widget; }"
                .to_string(),
        ),
    ];
    // Record the snapshot the way gen-stdlib-bundle does: same units,
    // same order, recording armed before the build.
    let mut model = sysmlv2_model::model::Model::new();
    for (name, src) in &lib_units {
        model.add_library_source(name.clone(), src);
    }
    model.record_library_cache();
    let _ = sysmlv2_model::json::ResolvedModel::build(&model);
    let snapshot = model
        .take_recorded_library_cache()
        .expect("recording armed before the build")
        .to_bytes();

    // Bytes survive the round-trip.
    assert!(sysmlv2_model::libcache::LibraryCache::from_bytes(&snapshot).is_some());
    assert!(
        sysmlv2_model::libcache::LibraryCache::from_bytes(&snapshot[..snapshot.len() - 1])
            .is_none()
    );

    let lib_json = sources(&[
        (
            "MiniLib.kerml",
            "standard library package MiniLib { class Thing; class Widget specializes Thing; }",
        ),
        (
            "MiniLib2.kerml",
            "standard library package MiniLib2 { class Gadget specializes MiniLib::Widget; }",
        ),
    ]);
    let user = sources(&[("uses.sysml", "package Uses { part g : MiniLib2::Gadget; }")]);

    let mut cold = Session::from_sources(&user).unwrap();
    cold.load_library_sources(&lib_json, None).unwrap();
    let mut warm = Session::from_sources(&user).unwrap();
    warm.load_library_sources(&lib_json, Some(snapshot.clone()))
        .unwrap();
    assert_eq!(cold.unresolved_count(), 0);
    assert_eq!(warm.unresolved_count(), 0);
    assert_eq!(
        cold.to_compact_json(),
        warm.to_compact_json(),
        "replayed build diverged from cold build"
    );

    // Garbage and truncated snapshots: rejected, cold-build fallback.
    let mut junk = Session::from_sources(&user).unwrap();
    junk.load_library_sources(&lib_json, Some(vec![0xde, 0xad, 0xbe, 0xef]))
        .unwrap();
    assert_eq!(cold.to_compact_json(), junk.to_compact_json());

    // A snapshot recorded against DIFFERENT library content: the
    // fingerprint mismatch disables replay, output stays correct.
    let other = sources(&[(
        "MiniLib.kerml",
        "standard library package MiniLib { class Thing; class Widget; }",
    )]);
    let mut stale = Session::from_sources(&user).unwrap();
    stale.load_library_sources(&other, Some(snapshot)).unwrap();
    // Widget no longer specializes Thing and MiniLib2 is gone entirely —
    // the user typing must now be unresolved, proving no stale replay.
    assert!(stale.unresolved_count() > 0);
}

#[test]
fn edit_batch_renames_and_reports_splices() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let battery = s.resolve("Flashlight::Battery").unwrap();
    let result = s
        .edit(
            &serde_json::json!([
                {"op": "rename", "target": "Flashlight::flashlight::battery", "newName": "powerCell"},
                {"op": "insertMember", "owner": "Flashlight::flashlight", "text": "part case2 : Body;"},
            ])
            .to_string(),
        )
        .expect("edit commits");
    let report: serde_json::Value = serde_json::from_str(&result).unwrap();

    // Splices replay over the pre-edit source to the post-edit source.
    let splices = report["splices"].as_array().unwrap();
    assert!(!splices.is_empty());
    let mut replayed = String::new();
    let mut cursor = 0usize;
    for sp in splices {
        assert_eq!(sp["unit"].as_str().unwrap(), "flashlight.sysml");
        replayed.push_str(&FLASHLIGHT[cursor..offset(&sp["start"])]);
        replayed.push_str(sp["text"].as_str().unwrap());
        cursor = offset(&sp["end"]);
    }
    replayed.push_str(&FLASHLIGHT[cursor..]);
    let post = s.source(0).unwrap();
    assert_eq!(replayed, post);
    assert!(post.contains("part powerCell : Battery;"));
    assert!(post.contains("part case2 : Body;"));
    assert!(!post.contains("part battery"));

    // The rename moved the usage's ownership path: idMap records it.
    assert!(report["idMap"].as_array().is_some_and(|m| !m.is_empty()));

    // The session was rebuilt: pre-edit handles are stale, re-resolving
    // sees the new state.
    assert!(s.metaclass(&battery).is_err());
    assert!(s.resolve("Flashlight::flashlight::powerCell").is_some());
    assert!(s.resolve("Flashlight::flashlight::battery").is_none());
}

#[test]
fn edit_batch_failures_leave_the_session_unchanged() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();

    // Unknown target fails before planning.
    let err = s
        .edit(r#"[{"op": "remove", "target": "Flashlight::Nope"}]"#)
        .unwrap_err();
    assert!(err.contains("element not found"), "{err}");

    // A remove blocked by outside references rolls back.
    let err = s
        .edit(r#"[{"op": "remove", "target": "Flashlight::Battery"}]"#)
        .unwrap_err();
    assert!(!err.is_empty());
    assert_eq!(s.source(0).unwrap(), FLASHLIGHT);
    // Handles minted before the failed batch still work (no rebuild).
    let body = s.resolve("Flashlight::Body").unwrap();
    assert_eq!(s.metaclass(&body).unwrap(), "PartDefinition");

    // Malformed ops are rejected with a parse error.
    let err = s.edit(r#"[{"op": "levitate"}]"#).unwrap_err();
    assert!(err.contains("bad edit ops"), "{err}");
    let err = s.edit("[]").unwrap_err();
    assert!(err.contains("empty edit batch"), "{err}");
}

#[test]
fn edit_batch_moves_members() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    // Reorder: `battery` before `body` (newOwner omitted = same owner).
    let result = s
        .edit(r#"[{"op": "moveMember", "target": "Flashlight::flashlight::battery", "index": 0}]"#)
        .expect("reorder commits");
    let report: serde_json::Value = serde_json::from_str(&result).unwrap();
    let post = s.source(0).unwrap();
    let battery_at = post.find("part battery : Battery;").unwrap();
    let body_at = post.find("part body : Body;").unwrap();
    assert!(battery_at < body_at, "not reordered:\n{post}");
    // Named members chain past their membership's ordinal (IDS.md,
    // id scheme 2): reordering named siblings moves no ids, so
    // the report's id map is empty and host selections survive as-is.
    assert!(
        report["idMap"].as_array().is_some_and(|m| m.is_empty()),
        "{report}"
    );

    // Re-parent: move `Body` (referenced) into the flashlight part —
    // `part body : Body;` still resolves it in the enclosing scope.
    s.edit(r#"[{"op": "moveMember", "target": "Flashlight::Body", "newOwner": "Flashlight::flashlight"}]"#)
        .expect("in-scope re-parent commits");
    assert!(s.resolve("Flashlight::flashlight::Body").is_some());
}

#[test]
fn edit_batch_sets_feature_types_and_grows_typed_values() {
    const SRC: &str = "package Lamp {\n    attribute def Volt;\n    attribute def Watt;\n    part def Bulb {\n        attribute watts : Watt;\n        attribute rating : Volt = 3;\n        attribute spare;\n    }\n}\n";
    let mut s = Session::from_sources(&sources(&[("lamp.sysml", SRC)])).unwrap();
    s.edit(
        &serde_json::json!([
            // The diagram editor's original defect: add a value to a
            // TYPED value-less feature.
            {"op": "setFeatureValue", "target": "Lamp::Bulb::watts", "expr": "60"},
            // Change a declared type in place; add one where none is.
            {"op": "setFeatureType", "target": "Lamp::Bulb::rating", "type": "Watt"},
            {"op": "setFeatureType", "target": "Lamp::Bulb::spare", "type": "Volt"},
        ])
        .to_string(),
    )
    .expect("edit commits");
    let post = s.source(0).unwrap();
    assert!(post.contains("attribute watts : Watt = 60;"), "{post}");
    assert!(post.contains("attribute rating : Watt = 3;"), "{post}");
    assert!(post.contains("attribute spare : Volt;"), "{post}");
}

#[test]
fn check_edit_dry_runs_without_touching_the_session() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let battery = s.resolve("Flashlight::Battery").unwrap();

    // Would commit: full report, session untouched, handles stay valid.
    let ops = r#"[{"op": "insertMember", "owner": "Flashlight::flashlight", "text": "part case2 : Body;"}]"#;
    let v: serde_json::Value = serde_json::from_str(&s.check_edit(ops).unwrap()).unwrap();
    assert_eq!(v["wouldCommit"], serde_json::json!(true));
    assert!(!v["splices"].as_array().unwrap().is_empty());
    assert_eq!(s.source(0).unwrap(), FLASHLIGHT);
    assert_eq!(s.metaclass(&battery).unwrap(), "PartDefinition");

    // The real edit produces the splices the check predicted.
    let committed: serde_json::Value = serde_json::from_str(&s.edit(ops).unwrap()).unwrap();
    assert_eq!(committed["splices"], v["splices"]);

    // Would refuse: the exact engine refusal, still no state change.
    let before = s.source(0).unwrap();
    let v: serde_json::Value = serde_json::from_str(
        &s.check_edit(r#"[{"op": "remove", "target": "Flashlight::Battery"}]"#)
            .unwrap(),
    )
    .unwrap();
    assert_eq!(v["wouldCommit"], serde_json::json!(false));
    assert!(v["refusal"].as_str().is_some_and(|r| !r.is_empty()));
    assert_eq!(s.source(0).unwrap(), before);

    // An unresolvable op target is a refusal too (the drag cue treats
    // it as a forbidden drop), not a transport error.
    let v: serde_json::Value = serde_json::from_str(
        &s.check_edit(r#"[{"op": "remove", "target": "Flashlight::Nope"}]"#)
            .unwrap(),
    )
    .unwrap();
    assert_eq!(v["wouldCommit"], serde_json::json!(false));
    assert!(v["refusal"].as_str().unwrap().contains("element not found"));

    // Malformed ops JSON is still an error.
    assert!(s.check_edit(r#"[{"op": "levitate"}]"#).is_err());
    assert!(s.check_edit("[]").is_err());
}

#[test]
fn to_graph_emits_identity_nodes() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let g: serde_json::Value = serde_json::from_str(&s.to_graph(None).unwrap()).unwrap();
    let nodes = g["nodes"].as_array().unwrap();
    assert!(
        nodes
            .iter()
            .any(|n| n["label"] == "Battery" && n["file"] == "flashlight.sysml")
    );
    assert!(g["edges"].as_array().is_some_and(|e| !e.is_empty()));
    assert!(s.to_graph(Some(r#"{"view":"sequence"}"#.into())).is_err());
}

#[test]
fn edit_removes_anonymous_connector_by_graph_edge_id() {
    const SRC: &str =
        "package Rig {\n    part pump;\n    part tank;\n    connect pump to tank;\n}\n";
    let mut s = Session::from_sources(&sources(&[("rig.sysml", SRC)])).unwrap();
    let g: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(r#"{"view":"interconnection"}"#.into()))
            .unwrap(),
    )
    .unwrap();
    let edge = g["edges"]
        .as_array()
        .unwrap()
        .iter()
        .find(|e| e["kind"] == "connect")
        .expect("connect edge");
    assert!(edge["qname"].is_null(), "anonymous connector");
    let target = format!("@{}", edge["id"].as_str().unwrap());
    s.edit(&serde_json::json!([{ "op": "remove", "target": target }]).to_string())
        .expect("remove by id commits");
    let post = s.source(0).unwrap();
    assert!(!post.contains("connect pump to tank;"), "{post}");
    assert!(post.contains("part pump;") && post.contains("part tank;"));
}

#[test]
fn edits_reject_library_elements_and_member_source_round_trips() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    s.load_library_sources(
        &sources(&[("lib.sysml", "package Lib { part def L; }")]),
        None,
    )
    .unwrap();

    // Library elements are read-only for every edit path.
    let err = s
        .edit(r#"[{"op": "rename", "target": "Lib::L", "newName": "M"}]"#)
        .unwrap_err();
    assert!(err.contains("read-only"), "{err}");
    let err = s.member_source("Lib::L").unwrap_err();
    assert!(err.contains("read-only"), "{err}");

    // Copy: the member's exact declaration text, body included…
    let text = s.member_source("Flashlight::Battery").unwrap();
    assert!(text.starts_with("part def Battery {"), "{text}");
    assert!(
        text.contains("attribute voltage = 3;") && text.ends_with('}'),
        "{text}"
    );

    // …pastes through insertMember (multi-line member text).
    s.edit(
        &serde_json::json!([{ "op": "insertMember", "owner": "Flashlight::flashlight",
            "text": text.replace("Battery", "SpareBattery") }])
        .to_string(),
    )
    .expect("paste commits");
    assert!(s.resolve("Flashlight::flashlight::SpareBattery").is_some());
}

#[test]
fn value_source_reports_the_bound_expression() {
    let mut s = Session::from_sources(&sources(&[(
        "m.sysml",
        "package M {\n    enum def Kind { low; high; }\n    part def P {\n        attribute k : Kind = Kind::high;\n        attribute v = 3 + 4;\n        attribute bare : Kind;\n    }\n}\n",
    )]))
    .unwrap();
    let v = s.resolve("M::P::v").unwrap();
    assert_eq!(s.value_source(&v).unwrap().as_deref(), Some("3 + 4"));
    let k = s.resolve("M::P::k").unwrap();
    assert_eq!(s.value_source(&k).unwrap().as_deref(), Some("Kind::high"));
    // No value part → no prefill (and no error).
    let bare = s.resolve("M::P::bare").unwrap();
    assert_eq!(s.value_source(&bare).unwrap(), None);
    // The evaluated value of a literal reference is the literal element
    // itself — how a value editor learns the current enum choice.
    let val: serde_json::Value = serde_json::from_str(&s.evaluate(&k).unwrap()).unwrap();
    let high = s.resolve("M::Kind::high").unwrap();
    assert_eq!(
        val["@element"],
        serde_json::json!(s.element_id(&high).unwrap())
    );
    // Declaration sites report unit + byte span — the name span the
    // rename op splices at, so a caller can place a cursor exactly on
    // the declared name.
    let site: serde_json::Value =
        serde_json::from_str(&s.declaration_site(&v).unwrap().expect("v has a site")).unwrap();
    let unit = offset(&site["unit"]);
    let src = s.source(unit).unwrap();
    let text = &src[offset(&site["start"])..offset(&site["end"])];
    assert_eq!(text, "v");
}

/// Two units: a part definition declared in one and referenced from
/// the other by an import, a specialization and a typing. The typed
/// usage's quoted name is one character of three bytes, so the byte
/// column of the `Wheel` after it (18) differs from its UTF-16 column
/// (16).
const WHEEL_DEFS: &str = "package Defs {\n    part def Wheel;\n    part def Hub;\n}\n";
const WHEEL_USES: &str = "package Rig {\n    import Defs::Wheel;\n    part def BigWheel :> Wheel;\n    part '☃' : Wheel;\n}\n";

/// A site as `references` reports it: unit, line, col, endLine, endCol.
fn site(v: &serde_json::Value) -> (String, u64, u64, u64, u64) {
    let n = |k: &str| v[k].as_u64().unwrap_or_else(|| panic!("{k} of {v}"));
    (
        v["unit"].as_str().expect("unit").to_string(),
        n("line"),
        n("col"),
        n("endLine"),
        n("endCol"),
    )
}

#[test]
fn references_report_every_site_and_the_declaration() {
    let mut s = Session::from_sources(&sources(&[
        ("defs.sysml", WHEEL_DEFS),
        ("uses.sysml", WHEEL_USES),
    ]))
    .unwrap();
    let before = (s.units(), s.state_digest());
    let wheel = s.resolve("Defs::Wheel").unwrap();

    let report: serde_json::Value =
        serde_json::from_str(&s.references("Defs::Wheel").unwrap()).unwrap();
    assert_eq!(
        site(&report["declaration"]),
        ("defs.sysml".to_string(), 2, 14, 2, 19)
    );
    assert_eq!(report["declaration"]["site"], "name");
    let refs = report["references"].as_array().expect("references");
    let sites: Vec<_> = refs.iter().map(site).collect();
    assert_eq!(
        sites,
        vec![
            // `import Defs::Wheel;` — the range is the `Wheel` segment,
            // not the whole qualified name.
            ("uses.sysml".to_string(), 2, 18, 2, 23),
            // `part def BigWheel :> Wheel;`
            ("uses.sysml".to_string(), 3, 26, 3, 31),
            // `part '☃' : Wheel;` — UTF-16 columns.
            ("uses.sysml".to_string(), 4, 16, 4, 21),
        ]
    );
    let kinds: Vec<&str> = refs.iter().map(|r| r["kind"].as_str().unwrap()).collect();
    assert_eq!(kinds, vec!["importedMembership", "superclassifier", "type"]);
    // Each is named for the nearest element above it with a qualified
    // name: the package the import sits in, the definition that
    // specializes, the usage that is typed.
    let owners: Vec<&str> = refs
        .iter()
        .map(|r| r["owner"]["qualifiedName"].as_str().unwrap())
        .collect();
    assert_eq!(owners, vec!["Rig", "Rig::BigWheel", "Rig::'☃'"]);
    let big = s.resolve("Rig::BigWheel").unwrap();
    assert_eq!(refs[1]["owner"]["id"], s.element_id(&big).unwrap());

    // The selector takes the forms `revealPath` takes.
    let as_json: serde_json::Value =
        serde_json::from_str(&s.references(r#""Defs::Wheel""#).unwrap()).unwrap();
    assert_eq!(as_json, report);
    let id = s.element_id(&wheel).unwrap();
    let by_id: serde_json::Value =
        serde_json::from_str(&s.references(&format!(r#"{{"elementId":"{id}"}}"#)).unwrap())
            .unwrap();
    assert_eq!(by_id, report);

    // An element nothing refers to still has its declaration.
    let hub: serde_json::Value = serde_json::from_str(&s.references("Defs::Hub").unwrap()).unwrap();
    assert_eq!(
        site(&hub["declaration"]),
        ("defs.sysml".to_string(), 3, 14, 3, 17)
    );
    assert_eq!(hub["references"], serde_json::json!([]));

    let err = s.references("Nope").unwrap_err();
    assert!(err.contains("element not found"), "{err}");

    // Reading usages writes nothing: the sources and the state are as
    // they were, and handles minted before are still good.
    assert_eq!((s.units(), s.state_digest()), before);
    assert_eq!(s.metaclass(&wheel).unwrap(), "PartDefinition");
}

/// The session's answer is the language server's references answer
/// with the declaration included, one-based: same units, same lines,
/// same UTF-16 columns.
#[test]
fn references_agree_with_the_language_server() {
    let defs = "file:///w/defs.sysml";
    let uses = "file:///w/uses.sysml";
    let mut s = Session::from_sources(&sources(&[(defs, WHEEL_DEFS), (uses, WHEEL_USES)])).unwrap();
    let report: serde_json::Value =
        serde_json::from_str(&s.references("Defs::Wheel").unwrap()).unwrap();
    let mut from_session = vec![site(&report["declaration"])];
    from_session.extend(report["references"].as_array().unwrap().iter().map(site));
    assert_eq!(from_session.len(), 4);

    let mut lsp = sysmlv2_wasm::LspServer::new();
    let open = |uri: &str, text: &str| {
        serde_json::json!({"jsonrpc": "2.0", "method": "textDocument/didOpen", "params": {
            "textDocument": {"uri": uri, "languageId": "sysml", "version": 1, "text": text}}})
        .to_string()
    };
    // No position encoding offered: the server answers in UTF-16.
    lsp.handle(r#"{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"capabilities":{}}}"#)
        .unwrap();
    lsp.handle(&open(defs, WHEEL_DEFS)).unwrap();
    lsp.handle(&open(uses, WHEEL_USES)).unwrap();
    // Asked from the declaration (`Wheel` on the second line of defs).
    let request =
        serde_json::json!({"jsonrpc": "2.0", "id": 2, "method": "textDocument/references",
        "params": {"textDocument": {"uri": defs}, "position": {"line": 1, "character": 14},
            "context": {"includeDeclaration": true}}})
        .to_string();
    let response = lsp
        .handle(&request)
        .unwrap()
        .into_iter()
        .map(|m| serde_json::from_str::<serde_json::Value>(&m).unwrap())
        .find(|m| m["id"] == 2)
        .expect("a response");
    let from_server: Vec<(String, u64, u64, u64, u64)> = response["result"]
        .as_array()
        .expect("locations")
        .iter()
        .map(|l| {
            let (start, end) = (&l["range"]["start"], &l["range"]["end"]);
            let n = |p: &serde_json::Value, k: &str| p[k].as_u64().unwrap() + 1;
            (
                l["uri"].as_str().unwrap().to_string(),
                n(start, "line"),
                n(start, "character"),
                n(end, "line"),
                n(end, "character"),
            )
        })
        .collect();
    assert_eq!(from_session, from_server);
}

/// The owner of a site is the nearest enclosing element that has a
/// qualified name, a KerML namespace among them; a site at the top level
/// of a unit has none. Kinds follow the notation: a namespace import
/// against a membership import, the qualifier of a qualified name,
/// connection ends as chain links, and the requirement a `satisfy`
/// names.
#[test]
fn references_name_the_enclosing_element_of_each_site() {
    let lib = "package L {\n    part def W { port p; }\n    requirement def R;\n}\n";
    let user = "import L::*;\npackage U {\n    import L::W;\n    part a : W;\n    part b : W;\n    connect a.p to b.p;\n    requirement r : R;\n    satisfy r by a;\n}\n";
    let kerml = "namespace N {\n    classifier K;\n    private import K::*;\n}\n";
    let mut s = Session::from_sources(&sources(&[
        ("lib.sysml", lib),
        ("u.sysml", user),
        ("n.kerml", kerml),
    ]))
    .unwrap();
    let sites = |s: &mut Session, target: &str| -> Vec<(u64, u64, String, Option<String>)> {
        let report: serde_json::Value =
            serde_json::from_str(&s.references(target).unwrap()).unwrap();
        report["references"]
            .as_array()
            .unwrap()
            .iter()
            .map(|r| {
                (
                    r["line"].as_u64().unwrap(),
                    r["col"].as_u64().unwrap(),
                    r["kind"].as_str().unwrap().to_string(),
                    r["owner"]["qualifiedName"].as_str().map(str::to_string),
                )
            })
            .collect()
    };
    let owned = |o: &str| Some(o.to_string());
    assert_eq!(
        sites(&mut s, "L"),
        vec![
            // `import L::*;` at the top of the unit: nothing encloses it.
            (1, 8, "importedNamespace".to_string(), None),
            // the `L` of `import L::W;`
            (3, 12, "qualifier".to_string(), owned("U")),
        ]
    );
    assert_eq!(
        sites(&mut s, "L::W"),
        vec![
            (3, 15, "importedMembership".to_string(), owned("U")),
            (4, 14, "type".to_string(), owned("U::a")),
            (5, 14, "type".to_string(), owned("U::b")),
        ]
    );
    // The connection is nameless: its ends are named for the package.
    assert_eq!(
        sites(&mut s, "U::a"),
        vec![
            (6, 13, "chainingFeature".to_string(), owned("U")),
            (8, 18, "memberElement".to_string(), owned("U")),
        ]
    );
    assert_eq!(
        sites(&mut s, "U::r"),
        vec![(8, 13, "referencedFeature".to_string(), owned("U"))]
    );
    // A KerML namespace has a qualified name like a package does.
    assert_eq!(
        sites(&mut s, "N::K"),
        vec![(3, 20, "importedNamespace".to_string(), owned("N"))]
    );

    // Inside a nameless element at the top of a unit nothing around
    // the reference has a qualified name, the named `z` included.
    let mut s = Session::from_sources(&sources(&[
        ("lib.sysml", lib),
        ("t.sysml", "part : L::W {\n    attribute z = L::W;\n}\n"),
    ]))
    .unwrap();
    assert_eq!(
        sites(&mut s, "L::W"),
        vec![
            (1, 11, "type".to_string(), None),
            (2, 22, "memberElement".to_string(), None),
        ]
    );
}

/// A nameless redefinition is reached through a chain (`med.chassis`
/// steps into `med`'s own `part :>> chassis`), yet declares no name to
/// range over: its declaration falls back to the member's whole
/// extent, and says so.
#[test]
fn references_fall_back_to_the_extent_of_a_nameless_declaration() {
    let model = "package P {\n    part def Chassis { attribute mass; }\n    part def Crawler { part chassis : Chassis; }\n    part med : Crawler { part :>> chassis { attribute :>> mass = 2; } }\n    attribute m = med.chassis.mass;\n}\n";
    let mut s = Session::from_sources(&sources(&[("p.sysml", model)])).unwrap();
    let redefining = s
        .resolve("P::med::chassis")
        .expect("the redefinition answers to the name it takes");
    assert_eq!(s.name(&redefining).unwrap(), None);
    let report: serde_json::Value =
        serde_json::from_str(&s.references("P::med::chassis").unwrap()).unwrap();
    assert_eq!(
        site(&report["declaration"]),
        ("p.sysml".to_string(), 4, 26, 4, 70),
        "`part :>> chassis {{ … }}`, body included"
    );
    assert_eq!(report["declaration"]["site"], "extent");
    let refs = report["references"].as_array().unwrap();
    assert_eq!(
        refs.iter().map(site).collect::<Vec<_>>(),
        vec![("p.sysml".to_string(), 5, 23, 5, 30)],
        "the `chassis` step of `med.chassis.mass`"
    );
    assert_eq!(refs[0]["kind"], "chainingFeature");
    // The chain is written in `m`'s value, which names the site.
    assert_eq!(refs[0]["owner"]["qualifiedName"], "P::m");
    // The named declaration it redefines is found by its name.
    let base: serde_json::Value =
        serde_json::from_str(&s.references("P::Crawler::chassis").unwrap()).unwrap();
    assert_eq!(base["declaration"]["site"], "name");
    assert_eq!(
        site(&base["declaration"]),
        ("p.sysml".to_string(), 3, 29, 3, 36)
    );
}

/// A declaration in a library unit is reported under the uri the
/// language server gives the unit, and the two answers agree there too.
#[test]
fn references_name_library_units_as_the_language_server_does() {
    let lib_unit = (
        "Mini Lib/MiniLib.sysml",
        "package MiniLib {\n    part def Widget;\n    part def Gadget :> Widget;\n}\n",
    );
    let user = "file:///w/m.sysml";
    let user_text = "package P {\n    part g : MiniLib::Widget;\n}\n";
    let library = sources(&[lib_unit]);
    let mut s = Session::from_sources(&sources(&[(user, user_text)])).unwrap();
    s.load_library_sources(&library, None).unwrap();
    let report: serde_json::Value =
        serde_json::from_str(&s.references("MiniLib::Widget").unwrap()).unwrap();
    let lib_uri = "sysmlv2-lib:/Mini%20Lib/MiniLib.sysml".to_string();
    assert_eq!(
        site(&report["declaration"]),
        (lib_uri.clone(), 2, 14, 2, 20)
    );
    assert_eq!(report["declaration"]["site"], "name");
    // The library's own `Gadget :> Widget` is no site: a library's
    // references are not recorded, only the model's into it.
    let refs = report["references"].as_array().unwrap();
    let sites: Vec<_> = refs.iter().map(site).collect();
    assert_eq!(sites, vec![(user.to_string(), 2, 23, 2, 29)]);
    assert_eq!(refs[0]["kind"], "type");
    assert_eq!(refs[0]["owner"]["qualifiedName"], "P::g");

    let mut from_session = vec![site(&report["declaration"])];
    from_session.extend(sites);
    let mut lsp = sysmlv2_wasm::LspServer::with_library(&library, None).unwrap();
    lsp.handle(r#"{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"capabilities":{}}}"#)
        .unwrap();
    lsp.handle(
        &serde_json::json!({"jsonrpc": "2.0", "method": "textDocument/didOpen", "params": {
            "textDocument": {"uri": user, "languageId": "sysml", "version": 1, "text": user_text}}})
        .to_string(),
    )
    .unwrap();
    // Asked from the user's `Widget` reference.
    let request =
        serde_json::json!({"jsonrpc": "2.0", "id": 2, "method": "textDocument/references",
        "params": {"textDocument": {"uri": user}, "position": {"line": 1, "character": 23},
            "context": {"includeDeclaration": true}}})
        .to_string();
    let response = lsp
        .handle(&request)
        .unwrap()
        .into_iter()
        .map(|m| serde_json::from_str::<serde_json::Value>(&m).unwrap())
        .find(|m| m["id"] == 2)
        .expect("a response");
    let from_server: Vec<(String, u64, u64, u64, u64)> = response["result"]
        .as_array()
        .expect("locations")
        .iter()
        .map(|l| {
            let (start, end) = (&l["range"]["start"], &l["range"]["end"]);
            let n = |p: &serde_json::Value, k: &str| p[k].as_u64().unwrap() + 1;
            (
                l["uri"].as_str().unwrap().to_string(),
                n(start, "line"),
                n(start, "character"),
                n(end, "line"),
                n(end, "character"),
            )
        })
        .collect();
    assert_eq!(from_session, from_server);
}

#[test]
fn verify_reports_verdicts_and_narrowed_ranges() {
    // One undecided constraint that propagation narrows, one violated
    // outright, one violated through a bound feature (bindings carry
    // the "why") — the solverless `verify --ranges` pipeline.
    let src = "package P {\n\
               \x20   attribute def Real;\n\
               \x20   attribute wingSpan : Real[1];\n\
               \x20   attribute margin : Real = 1;\n\
               \x20   assert constraint span { wingSpan >= 10 }\n\
               \x20   assert constraint bad { 1 > 2 }\n\
               \x20   assert constraint short { margin >= 2 }\n\
               }\n";
    let mut s = Session::from_sources(&sources(&[("t.sysml", src)])).unwrap();
    let report: serde_json::Value = serde_json::from_str(&s.verify(None).unwrap()).unwrap();

    let constraints = report["constraints"].as_array().unwrap();
    assert_eq!(constraints.len(), 3);
    let by_name = |n: &str| {
        constraints
            .iter()
            .find(|c| c["name"] == n)
            .unwrap_or_else(|| panic!("no constraint `{n}`"))
    };
    // Asserted ⇒ the constraint narrows the domain and then holds for
    // every value in it: propagation upgrades undecided → satisfied.
    let span = by_name("span");
    assert_eq!(span["status"], "satisfied");
    assert_eq!(span["method"], "propagation");
    assert!(
        span["detail"].as_str().unwrap().contains("propagation"),
        "{}",
        span["detail"]
    );
    assert_eq!(span["unitName"], "t.sysml");
    assert_eq!(span["elementType"], "AssertConstraintUsage");
    assert_eq!(span["line"], 5); // the result expression's line
    assert_eq!(span["features"], serde_json::json!(["wingSpan"]));
    let bad = by_name("bad");
    assert_eq!(bad["status"], "violated");
    assert_eq!(bad["method"], "evaluation");
    assert_eq!(bad["detail"], "VIOLATED"); // no references, no suffix

    // A violated constraint over a bound feature explains itself: the
    // detail carries the CLI's `(with …)` suffix and the bindings carry
    // the value plus the declaration position of `margin` (line 4).
    let short = by_name("short");
    assert_eq!(short["status"], "violated");
    assert_eq!(short["detail"], "VIOLATED (with margin = 1)");
    let b = &short["bindings"].as_array().unwrap()[0];
    assert_eq!(b["feature"], "margin");
    assert_eq!(b["value"], "1");
    assert_eq!(b["unitName"], "t.sysml");
    assert_eq!(b["line"], 4);

    let ranges = report["ranges"].as_array().unwrap();
    let ws = ranges
        .iter()
        .find(|r| r["feature"] == "wingSpan")
        .expect("wingSpan range");
    assert_eq!(ws["range"], "[10, +∞]");
    assert_eq!(ws["narrowed"], true);

    assert_eq!(report["summary"]["violated"], 2);
    assert_eq!(report["summary"]["satisfied"], 1);

    // Options plumb through; unknown keys are rejected.
    assert!(s.verify(Some(r#"{"maxIters": 5}"#.into())).is_ok());
    assert!(s.verify(Some(r#"{"nope": 1}"#.into())).is_err());
}

#[test]
fn verify_reports_one_verdict_per_satisfaction_claim() {
    // Each claim is positioned over its whole `satisfy` statement and
    // carries the constraint verdicts it combines, evaluated with the
    // requirement's subject bound to the satisfying part.
    let src = "package P {\n\
               \x20   part def Thing { attribute m; }\n\
               \x20   requirement def Cap {\n\
               \x20       subject t : Thing;\n\
               \x20       require constraint { t.m <= 5 }\n\
               \x20   }\n\
               \x20   requirement cap : Cap;\n\
               \x20   part small : Thing { attribute :>> m = 3; }\n\
               \x20   part big : Thing { attribute :>> m = 9; }\n\
               \x20   part site {\n\
               \x20       satisfy cap by small;\n\
               \x20       satisfy cap by big;\n\
               \x20   }\n\
               }\n";
    let mut s = Session::from_sources(&sources(&[("t.sysml", src)])).unwrap();
    let report: serde_json::Value = serde_json::from_str(&s.verify(None).unwrap()).unwrap();
    let claims = report["satisfactions"].as_array().unwrap();
    assert_eq!(claims.len(), 2);
    let small = &claims[0];
    assert_eq!(small["status"], "satisfied");
    assert_eq!(small["detail"], "satisfied");
    assert_eq!(small["requirement"], "P::cap");
    assert_eq!(small["by"], "small");
    assert_eq!(small["negated"], false);
    assert_eq!(small["unitName"], "t.sysml");
    assert_eq!((&small["line"], &small["col"]), (&11.into(), &9.into()));
    assert_eq!(
        (&small["endLine"], &small["endCol"]),
        (&11.into(), &30.into())
    );
    let big = &claims[1];
    assert_eq!(big["status"], "violated");
    assert_eq!(big["line"], 12);
    let parts = big["constraints"].as_array().unwrap();
    assert_eq!(parts.len(), 1);
    assert_eq!(parts[0]["status"], "violated");
    assert_eq!(parts[0]["assumed"], false);
    assert_eq!(parts[0]["detail"], "VIOLATED (with t.m = 9)");
    assert_eq!(parts[0]["line"], 5);
    assert_eq!(parts[0]["bindings"][0]["feature"], "t.m");
    assert_eq!(parts[0]["bindings"][0]["value"], "9");
    // The unbound original stays undecided; each claim counts once.
    assert_eq!(report["summary"]["satisfied"], 1);
    assert_eq!(report["summary"]["violated"], 1);
    assert_eq!(report["summary"]["undecided"], 1);
}

#[test]
fn lint_reports_configurable_findings_with_positions_and_fixes() {
    // A dead calc input (unused-parameter, default warn, deleting fix)
    // and a snake_case definition (naming-convention, default warn) —
    // the lint surface over the engine.
    let src = "package P {\n\
               \x20   attribute def Real;\n\
               \x20   part def dead_wheel;\n\
               \x20   calc def T { in force : Real; in radius : Real; return t : Real = force * 2; }\n\
               }\n";
    let mut s = Session::from_sources(&sources(&[("t.sysml", src)])).unwrap();
    // A config-less lint carries only the default-on nudges: the
    // snake_case definition at naming-convention's info default.
    let quiet: serde_json::Value = serde_json::from_str(&s.lint(None).unwrap()).unwrap();
    let quiet_findings = quiet["findings"].as_array().unwrap();
    assert_eq!(quiet_findings.len(), 1, "{quiet}");
    assert_eq!(quiet_findings[0]["rule"], "naming-convention");
    assert_eq!(quiet_findings[0]["severity"], "info");
    let on = r#"{ "rules": { "naming-convention": "warn", "unused-parameter": "warn" } }"#;
    let report: serde_json::Value =
        serde_json::from_str(&s.lint(Some(on.into())).unwrap()).unwrap();
    let findings = report["findings"].as_array().unwrap();
    assert_eq!(findings.len(), 2, "{findings:?}");
    let naming = &findings[0];
    assert_eq!(naming["rule"], "naming-convention");
    assert_eq!(naming["severity"], "warn");
    assert_eq!(naming["unitName"], "t.sysml");
    assert_eq!(naming["line"], 3);
    assert!(naming["message"].as_str().unwrap().contains("`dead_wheel`"));
    // The quick-fix hooks: edit-target spelling + style suggestion.
    assert_eq!(naming["element"], "P::dead_wheel");
    assert_eq!(naming["suggest"], "DeadWheel");
    let unused = &findings[1];
    assert_eq!(unused["rule"], "unused-parameter");
    assert_eq!(unused["line"], 4);
    let fix = &unused["fix"];
    assert_eq!(fix["deletes"], true);
    let edit = &fix["edits"].as_array().unwrap()[0];
    let unit = offset(&edit["unit"]);
    let cut = &s.source(unit).unwrap()[offset(&edit["start"])..offset(&edit["end"])];
    assert_eq!(cut, "in radius : Real;");
    assert_eq!(report["summary"]["warnings"], 2);
    assert_eq!(report["summary"]["errors"], 0);
    assert_eq!(report["summary"]["infos"], 0);
    assert_eq!(report["summary"]["hints"], 0);

    // The full severity ladder surfaces: info and hint levels parse
    // and tally into their own buckets.
    let soft = r#"{ "rules": { "naming-convention": "hint", "unused-parameter": "info" } }"#;
    let soft: serde_json::Value =
        serde_json::from_str(&s.lint(Some(soft.into())).unwrap()).unwrap();
    assert_eq!(soft["summary"]["hints"], 1, "{soft}");
    assert_eq!(soft["summary"]["infos"], 1);
    assert_eq!(soft["findings"][0]["severity"], "hint");
    assert_eq!(soft["findings"][1]["severity"], "info");

    // Config plumbs through: silence one rule, escalate the other;
    // unknown ids surface as lint-config findings with null positions.
    let cfg = r#"{ "rules": {
        "naming-convention": "off",
        "unused-parameter": "error",
        "no-such-rule": "warn" } }"#;
    let report: serde_json::Value =
        serde_json::from_str(&s.lint(Some(cfg.into())).unwrap()).unwrap();
    let findings = report["findings"].as_array().unwrap();
    assert_eq!(findings.len(), 2, "{findings:?}");
    assert_eq!(findings[0]["rule"], "lint-config");
    assert!(findings[0]["unit"].is_null() && findings[0]["line"].is_null());
    assert_eq!(findings[1]["rule"], "unused-parameter");
    assert_eq!(findings[1]["severity"], "error");
    assert_eq!(report["summary"]["errors"], 1);

    // Unreadable JSON is the only error.
    assert!(s.lint(Some("{nope".into())).is_err());

    // The rule inventory serves configuration UIs from the engine's
    // own registry: severities, scopes, styles, families, and typed
    // rule options.
    let rules: serde_json::Value = serde_json::from_str(&sysmlv2_wasm::lint_rules()).unwrap();
    let rules = rules.as_array().unwrap();
    assert!(rules.len() >= 5);
    let chain = rules
        .iter()
        .find(|r| r["id"] == "multiline-conditions")
        .unwrap();
    let min = &chain["options"][0];
    assert_eq!(min["key"], "min");
    assert_eq!(min["kind"], "int");
    assert_eq!(min["default"], 3);
    assert_eq!(min["min"], 2);
    assert!(min["zero"].as_str().unwrap().contains("inline"));
    let style = rules.iter().find(|r| r["id"] == "unit-spelling").unwrap()["options"][0].clone();
    assert_eq!(style["kind"], "choice");
    assert!(
        style["values"]
            .as_array()
            .unwrap()
            .iter()
            .any(|v| v == "expression")
    );
    let naming = rules
        .iter()
        .find(|r| r["id"] == "naming-convention")
        .unwrap();
    assert_eq!(naming["default"], "info");
    assert!(!naming["description"].as_str().unwrap().is_empty());
    assert!(
        naming["styles"]
            .as_array()
            .unwrap()
            .iter()
            .any(|s| s == "snake_case")
    );
    let fam = naming["families"].as_array().unwrap();
    assert_eq!(fam[0]["key"], "definitions");
    assert_eq!(fam[0]["defaultStyle"], "PascalCase");
    assert!(
        naming["scopes"]
            .as_array()
            .unwrap()
            .iter()
            .any(|s| s["key"] == "EnumerationUsage")
    );
    let untyped = rules.iter().find(|r| r["id"] == "untyped-usage").unwrap();
    let transition = untyped["scopes"]
        .as_array()
        .unwrap()
        .iter()
        .find(|s| s["key"] == "TransitionUsage")
        .expect("transition scope advertised")
        .clone();
    assert_eq!(transition["default"], "off");
    assert_eq!(transition["label"], "transition");
    let param = rules
        .iter()
        .find(|r| r["id"] == "unused-parameter")
        .unwrap();
    assert_eq!(param["scopes"].as_array().unwrap().len(), 3);
    assert!(param["styles"].as_array().unwrap().is_empty());
    // The textual tier's rule advertises its two typed options.
    let indent = rules.iter().find(|r| r["id"] == "indentation").unwrap();
    assert_eq!(indent["default"], "off");
    let opts = indent["options"].as_array().unwrap();
    assert_eq!(opts[0]["key"], "style");
    assert_eq!(opts[0]["kind"], "choice");
    assert_eq!(opts[0]["default"], "tabs");
    assert_eq!(opts[1]["key"], "size");
    assert_eq!(opts[1]["default"], 4);
    assert!(indent["scopes"].as_array().unwrap().is_empty());

    // …and it reaches this surface with the session's own text: the
    // four-space source above is off the tabs default on every indented
    // line, each with a re-indent fix over the leading whitespace.
    let tabs = r#"{ "rules": { "indentation": "warn", "naming-convention": "off" } }"#;
    let report: serde_json::Value =
        serde_json::from_str(&s.lint(Some(tabs.into())).unwrap()).unwrap();
    let findings = report["findings"].as_array().unwrap();
    assert_eq!(findings.len(), 3, "{findings:?}");
    assert_eq!(findings[0]["rule"], "indentation");
    assert_eq!(findings[0]["line"], 2);
    assert_eq!(findings[0]["col"], 1);
    assert_eq!(findings[0]["endCol"], 5);
    assert!(findings[0]["element"].is_null());
    let edit = &findings[0]["fix"]["edits"].as_array().unwrap()[0];
    assert_eq!(edit["replacement"], "\t");
    assert_eq!(findings[0]["fix"]["deletes"], false);

    // The style option flips the whole judgment: spaces of that width
    // are then the conforming form and this source is silent.
    let spaces = r#"{ "rules": { "naming-convention": "off",
                     "indentation": { "severity": "warn", "style": "spaces",
                     "size": 4 } } }"#;
    let report: serde_json::Value =
        serde_json::from_str(&s.lint(Some(spaces.into())).unwrap()).unwrap();
    assert_eq!(report["findings"].as_array().unwrap().len(), 0, "{report}");
}

#[test]
fn delta_between_rebases_independent_derivations() {
    use sysmlv2_wasm::{delta_cbor_between, describe_cbor};
    // The same text built under two unit names assigns ids from two
    // different unit-root seeds — a raw diff sees full churn, the
    // rebased diff sees the empty delta.
    let a = Session::from_sources(&sources(&[("a.sysml", FLASHLIGHT)])).unwrap();
    let b = Session::from_sources(&sources(&[("b.sysml", FLASHLIGHT)])).unwrap();
    let base = a.to_compact_json();
    let target = b.to_compact_json();

    let rebased = delta_cbor_between(&base, &target, false, true, None, None).unwrap();
    let d: serde_json::Value = serde_json::from_str(&describe_cbor(&rebased).unwrap()).unwrap();
    assert_eq!(d["delta"]["changes"]["creates"], 0, "rebased: no creates");
    assert_eq!(d["delta"]["changes"]["updates"], 0, "rebased: no updates");
    assert_eq!(d["delta"]["changes"]["deletes"], 0, "rebased: no deletes");

    let raw = delta_cbor_between(&base, &target, false, false, None, None).unwrap();
    let dr: serde_json::Value = serde_json::from_str(&describe_cbor(&raw).unwrap()).unwrap();
    assert!(
        dr["delta"]["changes"]["creates"].as_u64().unwrap() > 0,
        "raw diff of independent derivations churns"
    );

    // Portable mode carries text identities and allows lenient apply.
    let portable = delta_cbor_between(&base, &target, true, true, None, None).unwrap();
    let dp: serde_json::Value = serde_json::from_str(&describe_cbor(&portable).unwrap()).unwrap();
    assert_eq!(dp["delta"]["identityMode"], "portable");
}

#[test]
fn codec_tables_expose_the_wire_vocabulary() {
    use sysmlv2_wasm::codec_tables;
    let t: serde_json::Value = serde_json::from_str(&codec_tables(false)).unwrap();
    assert_eq!(t["tablesVersion"], 1);
    let metaclasses = t["metaclasses"].as_array().unwrap();
    // Position = wire type code; spot-check a known metaclass.
    let fre = metaclasses
        .iter()
        .position(|m| m["name"] == "FeatureReferenceExpression")
        .expect("FeatureReferenceExpression in the table");
    assert!(fre < metaclasses.len());
    let fields = metaclasses[fre]["fields"].as_array().unwrap();
    assert!(fields.iter().any(|f| f["prop"] == "declaredName"));
    // Enum vocabularies ride along.
    assert!(
        t["enums"]
            .as_array()
            .unwrap()
            .iter()
            .any(|e| e["name"] == "VisibilityKind")
    );
    // Full-form space is a superset per metaclass.
    let tf: serde_json::Value = serde_json::from_str(&codec_tables(true)).unwrap();
    assert!(tf["metaclasses"].as_array().unwrap().len() == metaclasses.len());
}

#[test]
fn foreign_payload_base_digests_and_applies_raw() {
    use sysmlv2_wasm::{delta_cbor_between, describe_cbor, state_digest_of};
    // A payload produced elsewhere: a session under its own unit name,
    // exported to compact JSON. The receiving session loads it keeping
    // the document's ids (explicit ids), so the loaded session *is* the
    // file's identity: its state digest equals the raw digest, and a
    // strict delta recorded against the file applies to the session as
    // well as to the caller-held base document.
    let producer = Session::from_sources(&sources(&[("v1.sysml", FLASHLIGHT)])).unwrap();
    let base_json = producer.to_compact_json();
    let target = Session::from_sources(&sources(&[(
        "v1.sysml",
        "package Flashlight {\n    part def Body;\n    part def Battery {\n        attribute voltage = 3;\n    }\n    part def Bulb;\n    part flashlight {\n        part body : Body;\n        part battery : Battery;\n    }\n}\n",
    )]))
    .unwrap();
    let delta = delta_cbor_between(
        &base_json,
        &target.to_compact_json(),
        false,
        true,
        None,
        None,
    )
    .unwrap();
    let d: serde_json::Value = serde_json::from_str(&describe_cbor(&delta).unwrap()).unwrap();
    let base_digest = d["delta"]["baseDigest"].as_str().unwrap();

    // Raw digest of the payload document = the delta's base digest = the
    // loaded session's digest.
    assert_eq!(state_digest_of(&base_json).unwrap(), base_digest);
    let receiver = Session::from_interchange_json(&base_json, None, None, None).unwrap();
    assert_eq!(
        receiver.state_digest(),
        base_digest,
        "a loaded payload keeps its ids, so the session is the file's identity"
    );

    // Strict apply: clean against the receiver's loaded model and
    // against the caller-held base document alike.
    let against_session: serde_json::Value =
        serde_json::from_str(&receiver.apply_delta_cbor(&delta, false).unwrap()).unwrap();
    assert_eq!(against_session["report"]["baseMatched"], true);
    let applied: serde_json::Value = serde_json::from_str(
        &receiver
            .apply_delta_cbor_to(&delta, &base_json, false)
            .unwrap(),
    )
    .unwrap();
    assert_eq!(applied["report"]["baseMatched"], true);
    assert_eq!(
        state_digest_of(&applied["result"].to_string()).unwrap(),
        d["delta"]["resultDigest"].as_str().unwrap(),
        "applying to the raw base reproduces the declared result state"
    );
}

/// The raw-result apply surface: replay chains must carry state
/// documents as emitted strings — a host JSON parser re-canonicalizes
/// number spellings (`3.0` → `3`), silently changing the compact-CBOR
/// encoding and the state digest. `applyDeltaCborToRaw` returns the
/// applied document as a string field so the host never parses it.
#[test]
fn raw_apply_result_is_digest_faithful() {
    use sysmlv2_wasm::{delta_cbor_between, describe_cbor, state_digest_of};
    let float_model = "package P {\n    part def D {\n        attribute mass = 3.0;\n    }\n}\n";
    let base = Session::from_sources(&sources(&[("m.sysml", float_model)])).unwrap();
    let base_json = base.to_compact_json();
    let target = Session::from_sources(&sources(&[(
        "m.sysml",
        "package P {\n    part def D {\n        attribute mass = 3.0;\n        attribute count;\n    }\n}\n",
    )]))
    .unwrap();
    let delta = delta_cbor_between(
        &base_json,
        &target.to_compact_json(),
        false,
        true,
        None,
        None,
    )
    .unwrap();
    let d: serde_json::Value = serde_json::from_str(&describe_cbor(&delta).unwrap()).unwrap();

    let raw = base
        .apply_delta_cbor_to_raw(&delta, &base_json, false)
        .unwrap();
    let wrapper: serde_json::Value = serde_json::from_str(&raw).unwrap();
    let result_json = wrapper["resultJson"].as_str().unwrap();
    assert_eq!(
        state_digest_of(result_json).unwrap(),
        d["delta"]["resultDigest"].as_str().unwrap(),
        "the string result digests to the declared result state"
    );
    assert!(wrapper["report"]["baseMatched"].as_bool().unwrap());
    // The hazard is real: the float spelling survives in the string
    // (a value round trip through a normalizing parser would not).
    assert!(
        result_json.contains("3.0"),
        "float spelling preserved verbatim"
    );
}

/// `formatQuery` — the `.kq` document formatter: fits stay inline,
/// long chains wrap, broken input is refused with its diagnostic.
#[test]
fn format_query_wraps_long_chains() {
    use sysmlv2_wasm::format_query;
    assert_eq!(format_query("a.b + 1", None, None).unwrap(), "a.b + 1");

    let long = "ownedFeature(Pkg::Program)->select { in p; p @ SysML::PartUsage }\
                ->collect { in m; (m meta SysML::PartUsage).declaredName }\
                ->reject { in n; n == \"skip\" }";
    let out = format_query(long, None, None).unwrap();
    assert!(out.contains("\n    ->select"), "chain wrapped:\n{out}");
    assert_eq!(format_query(&out, None, None).unwrap(), out, "idempotent");

    // An explicit narrow width wraps more; tabs indent with tabs.
    let tabbed = format_query(long, Some("tabs".into()), Some(40)).unwrap();
    assert!(tabbed.contains("\n\t->select"), "tab indent:\n{tabbed}");

    assert!(format_query("a +", None, None).is_err());
    assert!(format_query("part def X;", None, None).is_err());
}

/// `formatSource` — canonical model-text formatting under a project's
/// lint configuration: defaults format with tabs, the `indentation`
/// rule's style/size options carry through, output is idempotent, and
/// broken input is refused with a positioned message.
#[test]
fn format_source_follows_lint_config() {
    use sysmlv2_wasm::format_source_js;

    let messy =
        "package  P {\n      requirement <'REQ-1'>   illuminate   {\n   doc /* shine */\n }\n}";
    let out = format_source_js(messy, None).unwrap();
    assert!(
        out.contains("\n\trequirement <'REQ-1'> illuminate {"),
        "tab-indented canonical head:\n{out}"
    );
    assert_eq!(
        format_source_js(&out, None).unwrap(),
        out,
        "idempotent under defaults"
    );

    // Project style: two-space indentation via the indentation rule.
    let spaces =
        r#"{"rules": {"indentation": {"severity": "warn", "style": "spaces", "size": 2}}}"#;
    let spaced = format_source_js(messy, Some(spaces.into())).unwrap();
    assert!(
        spaced.contains("\n  requirement <'REQ-1'> illuminate {"),
        "two-space indent from config:\n{spaced}"
    );
    assert_eq!(
        format_source_js(&spaced, Some(spaces.into())).unwrap(),
        spaced,
        "idempotent under config"
    );

    // Broken input: refused with a 1-based line:col prefix.
    let err = format_source_js("part def {", None).unwrap_err();
    assert!(err.starts_with("1:"), "positioned refusal, got: {err}");
}

/// The canonical-name surface a generator relies on: reserved words
/// and non-basic names quote, basic names stay bare,
/// the dialect selects the reserved set, and the empty string is refused
/// — all without the caller seeing a keyword table.
#[test]
fn canonical_name_spells_like_the_printer() {
    let spell = |n: &str, d: Option<&str>| -> (String, bool) {
        let v: serde_json::Value =
            serde_json::from_str(&canonical_name_js(n, d.map(String::from)).unwrap()).unwrap();
        (
            v["spelling"].as_str().unwrap().to_string(),
            v["quoted"].as_bool().unwrap(),
        )
    };
    assert_eq!(spell("Node", None), ("Node".into(), false));
    assert_eq!(spell("part", None), ("'part'".into(), true));
    assert_eq!(spell("part", Some("kerml")), ("part".into(), false));
    assert_eq!(
        spell("no-referrer", Some("sysml")),
        ("'no-referrer'".into(), true)
    );
    assert_eq!(spell("it's", None), ("'it\\'s'".into(), true));
    assert!(canonical_name_js("", None).unwrap_err().contains("empty"));
    assert!(
        canonical_name_js("x", Some("cobol".into()))
            .unwrap_err()
            .contains("dialect")
    );
    // The quoted spelling is accepted by the parser as that very name.
    let src = format!("package P {{ part def {}; }}\n", spell("part", None).0);
    let findings = check(&sources(&[("p.sysml", &src)]), None, None).unwrap();
    assert_eq!(findings, "[]");
    let mut s = Session::from_sources(&sources(&[("p.sysml", &src)])).unwrap();
    let e = s
        .resolve("P::part")
        .expect("quoted reserved word resolves by value");
    assert_eq!(s.name(&e).unwrap().as_deref(), Some("part"));
}

/// The ambient library loads with any directory library (interim
/// mechanism) — no file needs naming, and it stays library content.
#[test]
fn ambient_library_loads_with_a_directory_library() {
    let dir = std::env::temp_dir().join(format!("sysmlv2-ambient-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    std::fs::write(
        dir.join("Tiny.sysml"),
        "library package Tiny { part def T; }\n",
    )
    .unwrap();
    let user =
        "package M {\n    metadata tag : TransformMeta::Generated;\n    part y : Tiny::T;\n}\n";
    let mut session =
        sysmlv2_transform::Session::from_sources(vec![("m.sysml".into(), user.into())])
            .unwrap()
            .with_library(&dir)
            .unwrap();
    let r = session.resolved();
    let generated = r
        .resolve_qualified("TransformMeta::Generated")
        .expect("TransformMeta resolves ambiently");
    assert!(r.is_library_element(generated));
    let tag = r.resolve_qualified("M::tag").unwrap();
    assert_eq!(r.typings(tag), [generated]);
    assert!(r.resolve_qualified("Tiny::T").is_some());
    let y = r.resolve_qualified("M::y").unwrap();
    assert!(!r.is_library_element(y));
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn anonymous_graph_elements_are_reachable_by_id() {
    let source = "package P { action a; action b; succession first a then b; constraint { true } }";
    let mut s = Session::from_sources(&sources(&[("anonymous.sysml", source)])).unwrap();
    let graph: serde_json::Value =
        serde_json::from_str(&s.to_graph(Some(r#"{"view":"tree"}"#.into())).unwrap()).unwrap();
    for kind in ["ConstraintUsage", "SuccessionAsUsage"] {
        let node = graph["nodes"]
            .as_array()
            .unwrap()
            .iter()
            .find(|n| n["metaclass"] == kind)
            .unwrap();
        let id = node["id"].as_str().unwrap();
        assert!(node.get("qname").is_none_or(serde_json::Value::is_null));
        assert!(s.resolve(&format!("@{id}")).is_none());
        let e = s.element_by_id(id).expect("graph ID resolves");
        assert_eq!(s.metaclass(&e).unwrap(), kind);
        assert_eq!(s.element_id(&e).unwrap(), id);
        assert_eq!(s.qualified_name(&e).unwrap(), None);
        assert!(s.declaration_site(&e).unwrap().is_some());
        assert!(s.member_source(&format!("@{id}")).is_ok());
    }
    assert_eq!(s.source(0).unwrap(), source);
    for id in [
        "",
        "not-an-id",
        "P::a",
        "00000000-0000-0000-0000-000000000000",
    ] {
        assert!(s.element_by_id(id).is_none());
    }
    let a = s.resolve("P::a").unwrap();
    let id = s.element_id(&a).unwrap();
    let a_by_id = s.element_by_id(&id).unwrap();
    s.edit(r#"[{"op":"rename","target":"P::a","newName":"renamed"}]"#)
        .unwrap();
    assert!(s.metaclass(&a_by_id).is_err());
    assert!(s.element_by_id(&id).is_none());
    let renamed = s.resolve("P::renamed").unwrap();
    let new_id = s.element_id(&renamed).unwrap();
    assert!(s.element_by_id(&new_id).is_some());
}

#[test]
fn id_lookup_preserves_library_read_only_and_handle_generation() {
    let mut s = Session::from_sources(&sources(&[("main.sysml", "package P;")])).unwrap();
    let p = s.resolve("P").unwrap();
    let id = s.element_id(&p).unwrap();
    let old = s.element_by_id(&id).unwrap();
    s.load_library_sources(
        &sources(&[(
            "mini.kerml",
            "standard library package Mini { class Thing; }",
        )]),
        None,
    )
    .unwrap();
    assert!(s.metaclass(&old).is_err());
    assert!(s.element_by_id(&id).is_some());
    let lib = s.resolve("Mini::Thing").unwrap();
    let lib_id = s.element_id(&lib).unwrap();
    let found = s.element_by_id(&lib_id).unwrap();
    assert!(s.is_library_element(&found).unwrap());
    let before = s.units();
    let error = s
        .edit(&serde_json::json!([{"op":"remove","target":format!("@{lib_id}")}]).to_string())
        .unwrap_err();
    assert!(error.contains("read-only"), "{error}");
    assert_eq!(s.units(), before);
}

/// A stand-in for the standard `Views` library package, loaded as a
/// library so that `asElementTable` is a library element, exactly as the
/// shipped library is.
const VIEWS_LIBRARY: &str = "standard library package Views {\n    rendering def Rendering;\n    rendering def TabularRendering :> Rendering;\n    rendering asElementTable : TabularRendering;\n}\n";

/// A matrix-view fixture over [`VIEWS_LIBRARY`]: the generated support
/// package, a model, and two views — one per tabular rendering — plus
/// a non-view.
fn matrix_view_session() -> Session {
    let mut s = Session::from_sources(&matrix_view_sources()).unwrap();
    s.load_library_sources(&sources(&[("Views.sysml", VIEWS_LIBRARY)]), None)
        .unwrap();
    s
}

fn matrix_view_sources() -> String {
    sources(&[
        (
            "matrix.sysml",
            "package MatrixViews {\n    import Views::*;\n    metadata def MatrixConfig {\n        attribute attributes[0..*];\n        attribute relationship[0..1];\n    }\n    rendering def RelationshipMatrix :> TabularRendering;\n    rendering asRelationshipMatrix : RelationshipMatrix;\n}\n",
        ),
        (
            "m.sysml",
            "package M {\n    part def A;\n    part def B;\n    part a : A;\n    part b : B;\n    part c {\n        part d;\n    }\n}\n",
        ),
        (
            "s.sysml",
            "package S {\n    import Views::*;\n    import MatrixViews::*;\n    view 'Part allocations' {\n        @MatrixConfig { relationship = \"allocation\"; }\n        expose M::a;\n        expose M::b;\n        view columns {\n            expose M::c::**;\n        }\n        render asRelationshipMatrix;\n    }\n    view masses {\n        @MatrixConfig { attributes = (\"mass\", \"voltage\"); }\n        expose M::*;\n        render asElementTable;\n    }\n    view nobody;\n    part notAView;\n}\n",
        ),
    ])
}

fn exposed_names(info: &serde_json::Value) -> Vec<&str> {
    info["exposed"]
        .as_array()
        .unwrap()
        .iter()
        .map(|e| e["qualifiedName"].as_str().unwrap())
        .collect()
}

#[test]
fn view_info_reports_exposure_rendering_and_metadata() {
    let mut s = matrix_view_session();
    let before = s.to_compact_json();
    let info: serde_json::Value =
        serde_json::from_str(&s.view_info("S::'Part allocations'").unwrap()).unwrap();
    assert_eq!(info["qualifiedName"], "S::'Part allocations'");
    assert_eq!(info["rendering"], "asRelationshipMatrix");
    assert_eq!(exposed_names(&info), ["M::a", "M::b"]);
    assert_eq!(info["exposed"][0]["metaclass"], "PartUsage");
    assert!(info["exposed"][0]["id"].as_str().unwrap().len() == 36);
    assert_eq!(info["views"][0]["name"], "columns");
    assert_eq!(
        info["views"][0]["qualifiedName"],
        "S::'Part allocations'::columns"
    );
    assert_eq!(info["metadata"][0]["type"], "MatrixViews::MatrixConfig");
    assert_eq!(info["metadata"][0]["values"]["relationship"], "allocation");
    // The recursive expose names its target and everything under it.
    let columns: serde_json::Value =
        serde_json::from_str(&s.view_info("S::'Part allocations'::columns").unwrap()).unwrap();
    assert_eq!(exposed_names(&columns), ["M::c", "M::c::d"]);
    assert_eq!(columns["rendering"], serde_json::Value::Null);
    assert!(columns["views"].as_array().unwrap().is_empty());
    let masses: serde_json::Value =
        serde_json::from_str(&s.view_info("S::masses").unwrap()).unwrap();
    // The standard rendering is a library element.
    assert_eq!(masses["rendering"], "asElementTable");
    // The reported name is the model's canonical spelling, whatever the
    // caller quoted.
    assert_eq!(masses["qualifiedName"], "S::masses");
    let quoted: serde_json::Value =
        serde_json::from_str(&s.view_info("S::'masses'").unwrap()).unwrap();
    assert_eq!(quoted["qualifiedName"], "S::masses");
    assert_eq!(quoted["id"], masses["id"]);
    assert_eq!(
        masses["metadata"][0]["values"]["attributes"],
        serde_json::json!(["mass", "voltage"])
    );
    assert_eq!(
        exposed_names(&masses),
        ["M::A", "M::B", "M::a", "M::b", "M::c"]
    );
    assert!(s.view_info("S::notAView").is_err());
    assert!(s.view_info("S::missing").is_err());
    assert_eq!(s.to_compact_json(), before, "reading a view writes nothing");
}

/// A view usage without a `render` member of its own reports the
/// rendering it inherits: from the definition that types it, or through
/// a view usage it specializes. The inherited rendering resolves where
/// its definition declares it, here through an import only that
/// definition's package has. A view's own `render` member takes
/// precedence over an inherited one.
#[test]
fn view_info_reports_an_inherited_rendering() {
    let mut s = Session::from_sources(&sources(&[(
        "views.sysml",
        "package M {\n    part a;\n    part b;\n}\npackage Defs {\n    private import Views::*;\n    view def Listing { render asElementTable; }\n}\npackage S {\n    rendering asOutline : Views::Rendering;\n    view def TV { render Views::asElementTable; }\n    view v : TV { expose M::*; }\n    view listed : Defs::Listing { expose M::*; }\n    view outlined : TV {\n        expose M::*;\n        render asOutline;\n    }\n    view narrowed :> v;\n}\n",
    )]))
    .unwrap();
    s.load_library_sources(&sources(&[("Views.sysml", VIEWS_LIBRARY)]), None)
        .unwrap();
    let before = s.to_compact_json();
    let info = |s: &mut Session, view: &str| -> serde_json::Value {
        serde_json::from_str(&s.view_info(view).unwrap()).unwrap()
    };
    let v = info(&mut s, "S::v");
    assert_eq!(v["rendering"], "asElementTable");
    assert_eq!(exposed_names(&v), ["M::a", "M::b"]);
    assert_eq!(info(&mut s, "S::listed")["rendering"], "asElementTable");
    assert_eq!(info(&mut s, "S::outlined")["rendering"], "asOutline");
    assert_eq!(info(&mut s, "S::narrowed")["rendering"], "asElementTable");
    assert_eq!(s.to_compact_json(), before, "reading a view writes nothing");
}

#[test]
fn view_directed_diagrams_show_the_exposure() {
    let mut s = matrix_view_session();
    let graph: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(
            r#"{"view": "tree", "element": "S::'Part allocations'"}"#.into(),
        ))
        .unwrap(),
    )
    .unwrap();
    let names: Vec<&str> = graph["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .filter_map(|n| n["qname"].as_str())
        .collect();
    assert!(
        names.contains(&"M::a") && names.contains(&"M::b"),
        "{names:?}"
    );
    assert!(!names.iter().any(|n| n.starts_with("S::")), "{names:?}");
    assert!(!names.contains(&"M::c"), "{names:?}");
    // A non-view element still scopes the diagram to its own subtree.
    let graph: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(r#"{"view": "tree", "element": "M::c"}"#.into()))
            .unwrap(),
    )
    .unwrap();
    let names: Vec<&str> = graph["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .filter_map(|n| n["qname"].as_str())
        .collect();
    assert!(
        names.contains(&"M::c") && names.contains(&"M::c::d"),
        "{names:?}"
    );
    let uml = s
        .to_plantuml(Some(r#"{"element": "S::'Part allocations'"}"#.into()))
        .unwrap();
    assert!(uml.starts_with("@startuml"));
    assert!(!uml.contains("Part allocations"), "{uml}");
    // A view exposing nothing draws nothing — never the whole model.
    let graph: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(r#"{"view": "tree", "element": "S::nobody"}"#.into()))
            .unwrap(),
    )
    .unwrap();
    assert!(graph["nodes"].as_array().unwrap().is_empty(), "{graph}");
    let uml = s
        .to_plantuml(Some(r#"{"element": "S::nobody"}"#.into()))
        .unwrap();
    assert!(!uml.contains("M::a") && !uml.contains("\"a\""), "{uml}");
}

/// A reserved word used as a name: `qualifiedName` keeps the
/// specification's bare spelling, `referenceSpelling` and
/// `spellReference` quote it, and only the quoted form parses when a
/// host splices it into an `expose`.
#[test]
fn reference_spelling_re_parses_in_an_expose() {
    const MODEL: &str =
        "package 'part' {\n    part def 'action';\n    part 'view' : 'action';\n}\n";
    let mut s = Session::from_sources(&sources(&[("m.sysml", MODEL)])).unwrap();
    let view = s.resolve("'part'::'view'").expect("quoted lookup");
    assert_eq!(
        s.qualified_name(&view).unwrap().as_deref(),
        Some("part::view")
    );
    assert_eq!(
        s.reference_spelling(&view).unwrap().as_deref(),
        Some("'part'::'view'")
    );
    assert_eq!(
        spell_reference_js("part::view", None).unwrap(),
        "'part'::'view'"
    );
    // The dialect selects the reserved set: neither word is KerML's.
    assert_eq!(
        spell_reference_js("part::view", Some("kerml".into())).unwrap(),
        "part::view"
    );
    assert_eq!(
        spell_reference_js("'My Views'::x", None).unwrap(),
        "'My Views'::x"
    );
    assert!(
        spell_reference_js("x", Some("cobol".into()))
            .unwrap_err()
            .contains("dialect")
    );
    let expose = |target: &str| -> serde_json::Value {
        let views =
            format!("package Views {{\n    view v {{\n        expose {target};\n    }}\n}}\n");
        let out = check(
            &sources(&[("m.sysml", MODEL), ("v.sysml", &views)]),
            None,
            None,
        )
        .unwrap();
        serde_json::from_str(&out).unwrap()
    };
    assert_eq!(expose("'part'::'view'"), serde_json::json!([]));
    let bare = expose("part::view");
    assert_eq!(bare[0]["severity"], "error", "{bare}");
    assert_eq!(
        bare[0]["stage"], "parse",
        "the bare form fails to parse: {bare}"
    );
}

#[test]
fn derived_properties_by_specification_name() {
    let mut s = Session::from_sources(&sources(&[("flashlight.sysml", FLASHLIGHT)])).unwrap();
    let flashlight = s.resolve("Flashlight::flashlight").unwrap();
    // A composition: element handles, and `{"@id"}` references as JSON.
    let features = s.derived_elements(&flashlight, "ownedFeature").unwrap();
    assert_eq!(features.len(), 2);
    let json: serde_json::Value =
        serde_json::from_str(&s.derived(&flashlight, "ownedFeature").unwrap()).unwrap();
    assert_eq!(json.as_array().unwrap().len(), 2);
    assert_eq!(
        json[0]["@id"].as_str(),
        Some(s.element_id(&features[0]).unwrap().as_str())
    );
    // A string and a null.
    assert_eq!(s.derived(&flashlight, "name").unwrap(), "\"flashlight\"");
    assert_eq!(s.derived(&flashlight, "shortName").unwrap(), "null");
    assert!(s.derived_elements(&flashlight, "name").unwrap().is_empty());
    // A reference-typed property: the typing's target as a handle and as JSON.
    let battery = s.resolve("Flashlight::flashlight::battery").unwrap();
    let types = s.derived_elements(&battery, "type").unwrap();
    assert_eq!(types.len(), 1);
    assert_eq!(
        s.qualified_name(&types[0]).unwrap().as_deref(),
        Some("Flashlight::Battery")
    );
    // Fidelity and the owned side, without a model.
    assert_eq!(Session::derives("PartUsage", "ownedFeature"), "exact");
    assert_eq!(Session::derives("PartUsage", "feature"), "passthrough");
    assert_eq!(Session::derives("PartUsage", "mayTimeVary"), "not-computed");
    assert_eq!(
        Session::derives("PartUsage", "declaredName"),
        "not-declared"
    );
    assert!(Session::is_owned_property("PartUsage", "declaredName"));
    assert!(
        Session::computed_names()
            .iter()
            .any(|n| n == "owningNamespace")
    );
    // A name the metaclass does not derive throws.
    assert!(s.derived(&flashlight, "declaredName").is_err());
    // A name the toolkit does not compute yet throws too.
    assert!(s.derived(&battery, "mayTimeVary").is_err());
    // A target outside the model: in the JSON, not among the handles.
    let mut s = Session::from_sources(&sources(&[(
        "m.sysml",
        "package P { part w : Missing; part def A { part x; } part def B :> A; }",
    )]))
    .unwrap();
    let w = s.resolve("P::w").unwrap();
    let json: serde_json::Value = serde_json::from_str(&s.derived(&w, "type").unwrap()).unwrap();
    assert_eq!(json[0]["outside"], true);
    assert_eq!(json[0]["spelling"], "Missing");
    assert!(json[0]["danglingId"].is_string());
    assert!(s.derived_elements(&w, "type").unwrap().is_empty());
    // The closure policy switches the inheritance-aware families, and
    // survives an edit of the session.
    let b = s.resolve("P::B").unwrap();
    assert_eq!(s.closure_policy(), "passthrough");
    assert!(s.derived_elements(&b, "feature").unwrap().is_empty());
    s.set_closure_policy("closure").unwrap();
    assert_eq!(s.closure_policy(), "closure");
    assert_eq!(s.derived_elements(&b, "feature").unwrap().len(), 1);
    s.edit(r#"[{"op": "moveMember", "target": "P::w", "index": 0}]"#)
        .expect("edit commits");
    assert_eq!(s.closure_policy(), "closure");
    let b = s.resolve("P::B").unwrap();
    assert_eq!(s.derived_elements(&b, "feature").unwrap().len(), 1);
    assert!(s.set_closure_policy("nonsense").is_err());
    s.set_closure_policy("passthrough").unwrap();
}

/// A rename clashing with a sibling's name is dropped from the batch
/// and reported; the rest of the batch (an ancestor-qualified respell
/// included) still commits.
#[test]
fn edit_batch_drops_colliding_renames_and_reports_them() {
    let src = "package 'A B' {\n    part def X;\n    part def x;\n}\npackage Q {\n    part def other_def;\n    part a : 'A B'::X;\n    part b : 'A B'::x;\n}\n";
    let mut s = Session::from_sources(&sources(&[("ab.sysml", src)])).unwrap();
    let result = s
        .edit(
            &serde_json::json!([
                {"op": "rename", "target": "'A B'", "newName": "AB"},
                {"op": "rename", "target": "'A B'::x", "newName": "X"},
                {"op": "rename", "target": "Q::other_def", "newName": "OtherDef"},
            ])
            .to_string(),
        )
        .expect("the batch commits without the clashing rename");
    let report: serde_json::Value = serde_json::from_str(&result).unwrap();
    let findings = report["findings"].as_array().unwrap();
    assert_eq!(findings.len(), 1, "{findings:?}");
    let f = findings[0].as_str().unwrap();
    assert!(f.contains("rename of `'A B'::x` to `X` skipped"), "{f}");
    assert!(f.contains("`'A B'::X` is already named `X`"), "{f}");
    let post = s.source(0).unwrap();
    assert!(post.contains("package AB {"), "{post}");
    assert!(post.contains("part def x;"), "{post}");
    assert!(post.contains("part a : AB::X;"), "{post}");
    assert!(post.contains("part b : AB::x;"), "{post}");
    assert!(post.contains("part def OtherDef;"), "{post}");
}

/// A session opened with its library reports the same check findings
/// as the free `check` over the same sources (minus the parse stage,
/// which `checkSyntax` carries) — one resolution instead of two.
#[test]
fn session_check_matches_free_check() {
    use sysmlv2_wasm::check_syntax;
    let lib = sources(&[(
        "MiniLib.kerml",
        "standard library package MiniLib { class Thing; datatype Num; }",
    )]);
    let user = sources(&[
        (
            "dangling.sysml",
            "package Dangling { part def W; part w : Missing; attribute a : W; }",
        ),
        (
            "ctx.sysml",
            "package Ctx { attribute def A { part p : Thing; } }",
        ),
    ]);
    let free: serde_json::Value =
        serde_json::from_str(&check(&user, Some(lib.clone()), None).unwrap()).unwrap();
    let mut s = Session::from_sources_with_library(&user, Some(lib), None).unwrap();
    let unresolved_before = s.unresolved_count();
    let session: serde_json::Value = serde_json::from_str(&s.check()).unwrap();
    assert_eq!(session, free, "session findings match the free check");
    let stages: Vec<&str> = free
        .as_array()
        .unwrap()
        .iter()
        .map(|f| f["stage"].as_str().unwrap())
        .collect();
    assert!(
        stages.contains(&"referential") && stages.contains(&"semantic"),
        "{stages:?}"
    );
    // The syntax stages alone: a parse-broken unit's findings, no model.
    let mixed = sources(&[
        ("bad.sysml", "part def {"),
        (
            "ctx.sysml",
            "package Ctx { attribute def A { part p : Thing; } }",
        ),
    ]);
    let syntax: serde_json::Value = serde_json::from_str(&check_syntax(&mixed).unwrap()).unwrap();
    let stages: Vec<&str> = syntax
        .as_array()
        .unwrap()
        .iter()
        .map(|f| f["stage"].as_str().unwrap())
        .collect();
    assert!(
        stages.iter().all(|s| *s == "parse" || *s == "context"),
        "{stages:?}"
    );
    assert!(stages.contains(&"parse"), "{stages:?}");
    // The session stays usable after checking: navigation and the
    // unresolved count read the same model.
    assert!(s.resolve("Dangling::w").is_some());
    assert!(unresolved_before >= 1);
    assert_eq!(
        s.unresolved_count(),
        unresolved_before,
        "checking drains nothing"
    );
    // Without a library the resolution stages are skipped, as in `check`.
    let mut bare = Session::from_sources(&user).unwrap();
    let bare: serde_json::Value = serde_json::from_str(&bare.check()).unwrap();
    let free_bare: serde_json::Value =
        serde_json::from_str(&check(&user, None, None).unwrap()).unwrap();
    assert_eq!(bare, free_bare);
}

/// Checking a session must not change what lint reports afterwards
/// (the import-visibility rule reads the resolver's import provenance).
#[test]
fn session_check_leaves_lint_findings_unchanged() {
    let lib = sources(&[(
        "MiniLib.kerml",
        "standard library package MiniLib { class Thing; datatype Num; }",
    )]);
    let user = sources(&[(
        "u.sysml",
        "package U { import MiniLib::*; part def W; part w : Thing; attribute n : Num = 3; }",
    )]);
    let rules = |s: &mut Session| -> Vec<String> {
        let v: serde_json::Value = serde_json::from_str(&s.lint(None).unwrap()).unwrap();
        v["findings"]
            .as_array()
            .unwrap()
            .iter()
            .map(|f| f["rule"].as_str().unwrap().to_string())
            .collect()
    };
    let mut fresh = Session::from_sources_with_library(&user, Some(lib.clone()), None).unwrap();
    let before = rules(&mut fresh);
    let mut checked = Session::from_sources_with_library(&user, Some(lib), None).unwrap();
    let _ = checked.check();
    let after = rules(&mut checked);
    assert!(
        before.iter().any(|r| r == "import-visibility"),
        "{before:?}"
    );
    assert_eq!(after, before, "lint after check == lint without check");
}

#[test]
fn sources_with_an_empty_unit_name_are_refused_at_the_boundary() {
    let bad = r#"[{"name": "ok.sysml", "text": "package A;"}, {"name": "", "text": "package B;"}]"#;
    let err = Session::from_sources(bad).err().expect("refused");
    assert!(err.contains("source 1 has an empty name"), "{err}");
    assert!(check(bad, None, None).unwrap_err().contains("empty name"));
    assert!(
        sysmlv2_wasm::check_syntax(bad)
            .unwrap_err()
            .contains("empty name")
    );
    assert!(
        sysmlv2_wasm::lenient_sources(bad)
            .unwrap_err()
            .contains("empty name")
    );
    // A library bundle is sources too.
    let err = Session::from_sources_with_library(
        &sources(&[("u.sysml", "package U;")]),
        Some(bad.to_string()),
        None,
    )
    .err()
    .expect("refused");
    assert!(err.contains("empty name"), "{err}");
}

#[test]
fn diagram_emitters_share_one_option_vocabulary() {
    let mut s = Session::from_sources(&sources(&[
        ("flashlight.sysml", FLASHLIGHT),
        ("extra.sysml", "package Extra { part def Case; }"),
    ]))
    .unwrap();
    // Unknown names are unknown on both paths, with the same message…
    let uml = s
        .to_plantuml(Some(r#"{"view": "nope"}"#.into()))
        .unwrap_err();
    assert!(uml.contains("unknown view: nope"), "{uml}");
    assert_eq!(
        s.to_graph(Some(r#"{"view": "nope"}"#.into())).unwrap_err(),
        uml
    );
    let uml = s
        .to_plantuml(Some(r#"{"lineStyle": "curvy"}"#.into()))
        .unwrap_err();
    assert!(uml.contains("unknown line style: curvy"), "{uml}");
    assert_eq!(
        s.to_graph(Some(r#"{"lineStyle": "curvy"}"#.into()))
            .unwrap_err(),
        uml
    );
    let uml = s
        .to_plantuml(Some(r#"{"element": "No::Such"}"#.into()))
        .unwrap_err();
    assert!(uml.contains("element not found: No::Such"), "{uml}");
    assert_eq!(
        s.to_graph(Some(r#"{"element": "No::Such"}"#.into()))
            .unwrap_err(),
        uml
    );
    let uml = s
        .to_plantuml(Some(r#"{"roots": ["No::Such"]}"#.into()))
        .unwrap_err();
    assert_eq!(
        s.to_graph(Some(r#"{"roots": ["No::Such"]}"#.into()))
            .unwrap_err(),
        uml
    );
    // …while a view the graph emitter lacks is a different refusal,
    // named canonically whatever alias the caller wrote.
    let err = s.to_graph(Some(r#"{"view": "seq"}"#.into())).unwrap_err();
    assert_eq!(err, "no structured-graph emitter for view: sequence");
    assert!(s.to_plantuml(Some(r#"{"view": "seq"}"#.into())).is_ok());
    // Every PlantUML option is accepted on the graph path, aliases included.
    let g: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(
            r#"{"view": "ic", "horizontal": true, "lineStyle": "ortho", "stdColor": true,
                "linkTemplate": "x://{file}:{line}", "showInherited": true, "roots": ["Extra"]}"#
                .into(),
        ))
        .unwrap(),
    )
    .unwrap();
    assert_eq!(g["view"], "interconnection");
    // `roots` scopes the graph exactly as it scopes the PlantUML.
    let g: serde_json::Value =
        serde_json::from_str(&s.to_graph(Some(r#"{"roots": ["Extra"]}"#.into())).unwrap()).unwrap();
    let labels: Vec<&str> = g["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .filter_map(|n| n["label"].as_str())
        .collect();
    assert!(
        labels.contains(&"Case") && !labels.contains(&"Battery"),
        "{labels:?}"
    );
    let uml = s
        .to_plantuml(Some(r#"{"roots": ["Extra"]}"#.into()))
        .unwrap();
    assert!(uml.contains("Case") && !uml.contains("Battery"), "{uml}");
}

#[test]
fn verify_positions_bindings_in_their_own_unit() {
    // The bound feature is declared in one unit and the constraints
    // that reference it in another: every position comes from its own
    // unit's line index, and one report shares the indexes.
    let defs = "package P {\n    attribute def Real;\n\n    attribute margin : Real = 1;\n}\n";
    let checks = "package Q {\n    private import P::*;\n    assert constraint short { margin >= 2 }\n    assert constraint wide { margin <= 2 }\n}\n";
    let mut s =
        Session::from_sources(&sources(&[("defs.sysml", defs), ("checks.sysml", checks)])).unwrap();
    let report: serde_json::Value = serde_json::from_str(&s.verify(None).unwrap()).unwrap();
    let constraints = report["constraints"].as_array().unwrap();
    assert_eq!(constraints.len(), 2);
    let short = constraints.iter().find(|c| c["name"] == "short").unwrap();
    assert_eq!(short["unitName"], "checks.sysml");
    assert_eq!(short["line"], 3);
    assert_eq!(short["status"], "violated");
    assert_eq!(short["detail"], "VIOLATED (with margin = 1)");
    let b = &short["bindings"].as_array().unwrap()[0];
    assert_eq!(b["feature"], "margin");
    assert_eq!(b["value"], "1");
    assert_eq!(b["unitName"], "defs.sysml");
    assert_eq!(b["line"], 4);
    let wide = constraints.iter().find(|c| c["name"] == "wide").unwrap();
    assert_eq!(wide["status"], "satisfied");
    assert_eq!(wide["unitName"], "checks.sysml");
    assert_eq!(wide["line"], 4);
    assert_eq!(report["summary"]["satisfied"], 1);
    assert_eq!(report["summary"]["violated"], 1);
}

const SUMMARY_MODEL: &str = "package P { package Q { part def A; part def B :> A; part q : A; } part def D { part d1 : Q::A; } part def L; }";

#[test]
fn to_graph_summary_resolves_selectors_and_reports_the_rest() {
    let mut s = Session::from_sources(&sources(&[("p.sysml", SUMMARY_MODEL)])).unwrap();
    let full: serde_json::Value = serde_json::from_str(&s.to_graph(None).unwrap()).unwrap();
    assert!(
        full.get("summary").is_none(),
        "no reply field without a request"
    );
    let d_id = full["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .find(|n| n["qname"] == "P::D")
        .unwrap()["id"]
        .as_str()
        .unwrap()
        .to_string();
    let req = format!(
        r#"{{"summary":{{"open":["P",{{"elementId":"{d_id}"}},"Nope::Missing",{{"elementId":"00000000-0000-0000-0000-000000000000"}}],"noteBudget":10,"leafBudget":50}}}}"#
    );
    let g: serde_json::Value = serde_json::from_str(&s.to_graph(Some(req)).unwrap()).unwrap();
    let resolved = g["summary"]["resolved"].as_array().unwrap();
    assert_eq!(resolved.len(), 2);
    assert_eq!(resolved[0]["qualifiedName"], "P");
    assert_eq!(resolved[1]["id"], d_id);
    assert_eq!(g["summary"]["unresolved"].as_array().unwrap().len(), 2);
    assert_eq!(g["summary"]["unresolved"][0], "Nope::Missing");
    let nodes = g["nodes"].as_array().unwrap();
    assert!(
        nodes.iter().any(|n| n["qname"] == "P::D::d1"),
        "the opened owner card draws its member"
    );
    let q = nodes.iter().find(|n| n["qname"] == "P::Q").unwrap();
    assert_eq!(q["summary"]["open"], false);
    assert!(nodes.iter().all(|n| n["qname"] != "P::Q::A"));
    // Unknown fields inside the summary object are rejected like any option.
    assert!(
        s.to_graph(Some(r#"{"summary":{"open":[],"bogus":1}}"#.into()))
            .unwrap_err()
            .contains("bad options")
    );
    assert!(
        s.to_graph(Some(
            r#"{"view":"interconnection","summary":{"open":[]}}"#.into()
        ))
        .unwrap_err()
        .contains("tree-only")
    );
    // An empty roots list means the whole model, as without a summary:
    // the root package draws closed, and the reply field rides along.
    let whole: serde_json::Value = serde_json::from_str(
        &s.to_graph(Some(r#"{"roots":[],"summary":{"open":[]}}"#.into()))
            .unwrap(),
    )
    .unwrap();
    assert_eq!(whole["nodes"].as_array().unwrap().len(), 1);
    assert!(whole.get("summary").is_some());
    // The PlantUML path ignores the field.
    assert!(
        s.to_plantuml(Some(r#"{"summary":{"open":["P"]}}"#.into()))
            .unwrap()
            .starts_with("@startuml")
    );
}

#[test]
fn reveal_path_walks_owners_root_first() {
    let mut s = Session::from_sources(&sources(&[("p.sysml", SUMMARY_MODEL)])).unwrap();
    let by_name: serde_json::Value =
        serde_json::from_str(&s.reveal_path("P::Q::A").unwrap()).unwrap();
    let names: Vec<&str> = by_name
        .as_array()
        .unwrap()
        .iter()
        .map(|e| e["qualifiedName"].as_str().unwrap())
        .collect();
    assert_eq!(names, vec!["P", "P::Q"]);
    let as_json: serde_json::Value =
        serde_json::from_str(&s.reveal_path(r#""P::Q::A""#).unwrap()).unwrap();
    assert_eq!(as_json, by_name);
    let q_id = by_name[1]["id"].as_str().unwrap();
    let by_id: serde_json::Value = serde_json::from_str(
        &s.reveal_path(&format!(r#"{{"elementId":"{q_id}"}}"#))
            .unwrap(),
    )
    .unwrap();
    assert_eq!(by_id.as_array().unwrap().len(), 1, "Q's only owner is P");
    let root: serde_json::Value = serde_json::from_str(&s.reveal_path("P").unwrap()).unwrap();
    assert_eq!(root.as_array().unwrap().len(), 0);
    assert!(s.reveal_path("Nope").is_err());
}

#[test]
fn redefined_chain_reads_the_links_of_a_nameless_chain_redefinition() {
    let model = "package P {\n    attribute def MassValue;\n    part def Chassis { attribute mass : MassValue; attribute wheelbase : MassValue; }\n    part def Crawler { part chassis : Chassis; }\n    part med : Crawler { attribute :>> chassis.mass; }\n    part tiny : Crawler { part :>> chassis { attribute :>> mass; } }\n}\n";
    let mut s = Session::from_sources(&sources(&[("m.sysml", model)])).unwrap();
    let med = s.resolve("P::med").unwrap();
    let row = s.members(&med).unwrap().remove(0);
    let links = s.redefined_chain(&row).unwrap();
    let names: Vec<_> = links.iter().map(|l| s.qualified_name(l).unwrap()).collect();
    assert_eq!(
        names,
        [
            Some("P::Crawler::chassis".into()),
            Some("P::Chassis::mass".into())
        ]
    );
    let tiny = s.resolve("P::tiny").unwrap();
    let chassis = s.members(&tiny).unwrap().remove(0);
    assert!(s.redefined_chain(&chassis).unwrap().is_empty());
    let nested = s.members(&chassis).unwrap().remove(0);
    assert!(s.redefined_chain(&nested).unwrap().is_empty());
    // the link of a chain resolves through the feature that redefines it on the way
    let model = "package P {\n    attribute def MassValue;\n    part def Chassis { attribute mass : MassValue; }\n    part def Crawler { part chassis : Chassis { attribute :>> mass = 1; } }\n    part med : Crawler { attribute :>> chassis.mass; }\n}\n";
    let mut s = Session::from_sources(&sources(&[("m.sysml", model)])).unwrap();
    let med = s.resolve("P::med").unwrap();
    let row = s.members(&med).unwrap().remove(0);
    let links = s.redefined_chain(&row).unwrap();
    let names: Vec<_> = links.iter().map(|l| s.qualified_name(l).unwrap()).collect();
    assert_eq!(
        names,
        [
            Some("P::Crawler::chassis".into()),
            Some("P::Crawler::chassis::mass".into())
        ]
    );
}

#[test]
fn edit_batch_sets_a_comment_body_by_its_graph_id() {
    // A diagram note carries its comment's id; the body edit addresses it
    // by `@id` and rewrites only the `/* … */` token.
    const SRC: &str = "package Lamp {\n    part def Bulb {\n        doc /* old */\n    }\n    comment about Bulb /* first */\n}\n";
    let mut s = Session::from_sources(&sources(&[("lamp.sysml", SRC)])).unwrap();
    let g: serde_json::Value =
        serde_json::from_str(&s.to_graph(Some(r#"{"showNotes":true}"#.into())).unwrap()).unwrap();
    let notes: Vec<&serde_json::Value> = g["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|n| n["kind"] == "note")
        .collect();
    let id_of = |label: &str| {
        notes
            .iter()
            .find(|n| n["label"] == label)
            .map(|n| format!("@{}", n["id"].as_str().unwrap()))
            .unwrap()
    };
    let (doc, comment) = (id_of("old"), id_of("first"));
    s.edit(
        &serde_json::json!([
            {"op": "setCommentBody", "target": doc, "body": "line one\nline two"},
            {"op": "setCommentBody", "target": comment, "body": "second"},
        ])
        .to_string(),
    )
    .expect("edit commits");
    assert_eq!(
        s.source(0).unwrap(),
        "package Lamp {\n    part def Bulb {\n        doc /*\n         * line one\n         * line two\n         */\n    }\n    comment about Bulb /* second */\n}\n"
    );
    let err = s
        .edit(r#"[{"op": "setCommentBody", "target": "Lamp::Bulb", "body": "x"}]"#)
        .unwrap_err();
    assert!(err.contains("no comment body"), "{err}");
}
