//! Graph and PlantUML consume the same semantic transition endpoints.
use sysmlv2_model::{json::ResolvedModel, model::Model};
use sysmlv2_viz::{View, VizOptions, graph, plantuml};

fn check_transitions(source: &str, view: View, expected: &[(&str, &str, Option<&str>)]) {
    let mut model = Model::new();
    let unit = model.add_source("transitions.sysml", source);
    assert!(unit.diagnostics.is_empty(), "{:?}", unit.diagnostics);
    let mut resolved = ResolvedModel::build(&model);
    let options = VizOptions::default().with_view(view);
    let graph = graph(&mut resolved, None, &options).unwrap();
    let nodes = graph["nodes"].as_array().unwrap();
    let edges = graph["edges"].as_array().unwrap();
    assert_eq!(edges.len(), expected.len(), "{graph}");
    let uml = plantuml(&mut resolved, None, &options);
    assert_eq!(
        uml.lines().filter(|line| line.contains(" --> ")).count(),
        expected.len(),
        "{uml}"
    );
    let node_id =
        |label: &str| nodes.iter().find(|node| node["label"] == label).unwrap()["id"].clone();
    let alias = |label: &str| {
        let marker = format!("\"{label}\" as ");
        let start = uml.find(&marker).unwrap() + marker.len();
        uml[start..].split_whitespace().next().unwrap()
    };
    for &(source, target, label) in expected {
        let edge = edges
            .iter()
            .find(|edge| edge["source"] == node_id(source) && edge["target"] == node_id(target))
            .unwrap_or_else(|| panic!("missing {source} -> {target}: {graph}"));
        assert_eq!(edge["kind"], "transition");
        assert_eq!(edge["metaclass"], "TransitionUsage");
        assert_eq!(edge["directed"], true);
        assert_eq!(edge["label"].as_str(), label);
        let element = resolved
            .element_by_id(edge["id"].as_str().unwrap())
            .unwrap();
        assert_eq!(resolved.element_type(element), "TransitionUsage");
        assert_eq!(
            resolved.declaration_position(element).unwrap().0,
            "transitions.sysml"
        );
        let expected_line = format!(
            "{} --> {}{}",
            alias(source),
            alias(target),
            label.map(|label| format!(" : {label}")).unwrap_or_default(),
        );
        assert!(
            uml.lines().any(|line| line.trim() == expected_line),
            "{uml}"
        );
    }
}

#[test]
fn explicit_guarded_action_transitions_render_for_definitions_and_usages() {
    for declaration in ["action def Router", "action router", "action"] {
        check_transitions(
            &format!(
                "{declaration} {{
                attribute ok : Boolean;
                action ingest; action fast; action slow;
                transition route first ingest if ok then fast;
                first ingest if not ok then slow;
            }}"
            ),
            View::Action,
            &[
                ("ingest", "fast", Some("[ok]")),
                ("ingest", "slow", Some("[not ok]")),
            ],
        );
    }
}

#[test]
fn implicit_action_transition_sources_and_default_branches_match_plantuml() {
    for declaration in ["action def Router", "action router", "action"] {
        for transition in ["transition", ""] {
            check_transitions(
                &format!(
                    "{declaration} {{
                    attribute ok : Boolean;
                    action fast; action slow; action ingest;
                    {transition} if ok then fast;
                    else slow;
                }}"
                ),
                View::Action,
                &[("ingest", "fast", Some("[ok]")), ("ingest", "slow", None)],
            );
        }
    }
}

#[test]
fn explicit_and_implicit_state_transition_sources_match_plantuml() {
    for declaration in ["state def Modes", "state modes", "state"] {
        for transition in ["transition", ""] {
            for source in ["first idle", ""] {
                check_transitions(
                    &format!(
                        "{declaration} {{
                        attribute ok : Boolean;
                        state busy; state stopped; state idle;
                        {transition} {source} if ok then busy;
                        else stopped;
                    }}"
                    ),
                    View::State,
                    &[("idle", "busy", Some("[ok]")), ("idle", "stopped", None)],
                );
            }
        }
    }
}

#[test]
fn explicit_unresolved_transition_sources_do_not_fall_back_to_a_previous_node() {
    for (declaration, node, view) in [
        ("action def Router", "action", View::Action),
        ("state def Modes", "state", View::State),
    ] {
        check_transitions(
            &format!(
                "{declaration} {{
                {node} target; {node} previous;
                transition first missing if true then target;
            }}"
            ),
            view,
            &[],
        );
    }
}

#[test]
fn explicit_action_transition_preserves_trigger_guard_and_effect() {
    check_transitions(
        "item def Go; action def Notify;
        action def Router {
            attribute ok : Boolean;
            action ingest; action fast;
            transition route first ingest accept Go if ok do action notifier : Notify then fast;
        }",
        View::Action,
        &[("ingest", "fast", Some("Go [ok] / notifier : Notify"))],
    );
}

#[test]
fn named_state_transition_keeps_identity_and_an_ordinary_guardless_edge_has_no_label() {
    check_transitions(
        "state def Modes {
            state idle; state busy; state stopped;
            transition route first idle if true then busy;
            transition stop first busy then stopped;
        }",
        View::State,
        &[("idle", "busy", Some("[true]")), ("busy", "stopped", None)],
    );
}

#[test]
fn transitions_in_transparent_containers_emit_once_with_semantic_endpoints() {
    check_transitions(
        "part container {
            attribute ok : Boolean;
            action fast; action slow; action ingest;
            if ok then fast;
            else slow;
        }",
        View::Action,
        &[("ingest", "fast", Some("[ok]")), ("ingest", "slow", None)],
    );
}

#[test]
fn named_and_anonymous_decisions_are_native_sources_for_both_conditional_branches() {
    for (declaration, label) in [("decide branch", "branch"), ("decide", "(choice)")] {
        check_transitions(
            &format!(
                "action def Router {{
                attribute ok : Boolean;
                action fast; action slow;
                {declaration};
                if ok then fast;
                else slow;
            }}"
            ),
            View::Action,
            &[(label, "fast", Some("[ok]")), (label, "slow", None)],
        );
    }
}
